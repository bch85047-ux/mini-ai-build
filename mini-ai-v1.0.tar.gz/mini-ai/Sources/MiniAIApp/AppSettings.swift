// AppSettings.swift
// Author: 海鸥
// Purpose: 应用设置 - 持久化到UserDefaults

import Foundation
import SwiftUI
import Combine
import MiniAICore

@MainActor
final class AppSettings: ObservableObject {
    @AppStorage("ai_backend") var backend: String = "ollama"
    @AppStorage("ai_model") var model: String = "gpt-4o-mini"
    @AppStorage("ai_server_ip") var serverIP: String = ""
    @AppStorage("ai_port") var port: Int = 11434
    @AppStorage("ai_api_key") var apiKey: String = ""
    @AppStorage("ai_base_url") var customBaseURL: String = ""
    @AppStorage("ai_brave_key") var braveKey: String = ""
    @AppStorage("ai_max_rounds") var maxRounds: Int = 8
    @AppStorage("ai_temperature") var temperature: Double = 0.7
    @AppStorage("ai_system_prompt") var systemPrompt: String = SystemPrompts.base
    @AppStorage("ai_demo_mode") var demoMode: Bool = false

    static let shared = AppSettings()

    /// 可用的后端列表
    static let backends: [(name: String, displayName: String, defaultModel: String, defaultURL: String, needsKey: Bool)] = [
        ("openai", "OpenAI", "gpt-4o-mini", "https://api.openai.com/v1", true),
        ("ollama", "Ollama (本地)", "qwen2.5:7b-instruct", "", false),
        ("llamacpp", "llama.cpp", "qwen2.5-7b", "", false),
        ("lmstudio", "LM Studio", "local-model", "", true),
        ("groq", "Groq (免费)", "llama3-70b-8192", "https://api.groq.com/openai/v1", true),
        ("mistral", "Mistral AI", "mistral-small-latest", "https://api.mistral.ai/v1", true),
        ("custom", "自定义", "model", "", true),
    ]

    /// 构建当前配置的ModelRunner
    func makeRunner() -> OpenAIRunner {
        let baseUrlString: String
        
        if backend == "custom" && !customBaseURL.isEmpty {
            baseUrlString = customBaseURL
        } else if !serverIP.isEmpty {
            // 本地服务器
            switch backend {
            case "ollama":
                baseUrlString = "http://\(serverIP):\(port)/api"
            case "llamacpp":
                baseUrlString = "http://\(serverIP):\(port)"
            case "lmstudio":
                baseUrlString = "http://\(serverIP):\(port)/v1"
            default:
                baseUrlString = "http://\(serverIP):\(port)/v1"
            }
        } else {
            // 云端服务
            switch backend {
            case "openai":
                baseUrlString = "https://api.openai.com/v1"
            case "groq":
                baseUrlString = "https://api.groq.com/openai/v1"
            case "mistral":
                baseUrlString = "https://api.mistral.ai/v1"
            default:
                baseUrlString = "https://api.openai.com/v1"
            }
        }
        
        let key = apiKey.isEmpty ? nil : apiKey
        let defaultModel = Self.backends.first { $0.name == backend }?.defaultModel ?? "gpt-4o-mini"
        
        return OpenAIRunner(config: .init(
            baseURL: URL(string: baseUrlString)!,
            apiKey: key,
            model: model.isEmpty ? defaultModel : model,
            temperature: temperature,
            contextLength: 8192
        ))
    }
    
    /// 测试连接
    func testConnection() async -> Bool {
        let runner = makeRunner()
        do {
            let response = try await runner.chat(
                messages: [ChatMessage(role: "user", content: "测试连接")],
                stream: false
            )
            return !response.isEmpty
        } catch {
            print("Connection test failed: \(error)")
            return false
        }
    }
}
