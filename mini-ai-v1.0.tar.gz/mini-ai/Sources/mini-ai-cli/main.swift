// main.swift
// Author: 海鸥
// Purpose: CLI入口 - 命令行交互式聊天
// Usage: swift run mini-ai-cli [--backend ollama|llamacpp|lmstudio|custom] [--model NAME] [--port N] [--url URL] [--key KEY]

import Foundation
import MiniAICore

// MARK: - 参数解析
struct CLIArgs {
    var backend: String = "ollama"
    var model: String = "qwen2.5:7b-instruct"
    var port: Int = 11434
    var url: String? = nil
    var key: String? = nil
    var braveKey: String? = nil
    var maxRounds: Int = 8
    var help: Bool = false
}

func parseArgs(_ argv: [String]) -> CLIArgs {
    var args = CLIArgs()
    var i = 0
    while i < argv.count {
        let a = argv[i]
        switch a {
        case "--help", "-h": args.help = true
        case "--backend": if i+1 < argv.count { args.backend = argv[i+1]; i += 1 }
        case "--model": if i+1 < argv.count { args.model = argv[i+1]; i += 1 }
        case "--port": if i+1 < argv.count { args.port = Int(argv[i+1]) ?? args.port; i += 1 }
        case "--url": if i+1 < argv.count { args.url = argv[i+1]; i += 1 }
        case "--key": if i+1 < argv.count { args.key = argv[i+1]; i += 1 }
        case "--brave-key": if i+1 < argv.count { args.braveKey = argv[i+1]; i += 1 }
        case "--max-rounds": if i+1 < argv.count { args.maxRounds = Int(argv[i+1]) ?? 8; i += 1 }
        default: print("Unknown flag: \(a)")
        }
        i += 1
    }
    return args
}

func showHelp() {
    print("""
    mini-ai-cli — 本地AI命令行助手
    
    Usage:
      swift run mini-ai-cli [options]
    
    Options:
      --backend <name>    ollama (default) | llamacpp | lmstudio | custom
      --model <name>      Model name (default: qwen2.5:7b-instruct)
      --port <num>        Server port (default: 11434)
      --url <url>         Custom API base URL (overrides --port)
      --key <key>         API key (optional)
      --brave-key <key>   Brave Search API key (best search quality)
      --max-rounds <n>    Max tool-calling rounds (default: 8)
      --help              Show this help
    
    Backends:
      ollama     http://localhost:11434/api       (brew install ollama)
      llamacpp   http://localhost:8080            (llama.cpp server)
      lmstudio   http://localhost:1234/v1         (LM Studio)
      custom     Use --url
    
    Model suggestions:
      ollama:   qwen2.5:7b-instruct, deepseek-r1:8b, llama3.1:8b
      ollama 16GB: qwen2.5:14b-instruct, deepseek-r1:14b
      custom abliterated: /path/to/Qwen2.5-7B-Instruct-abliterated-4bit
    """)
}

// MARK: - 构建Runner
func makeRunner(_ args: CLIArgs) -> OpenAIRunner {
    if let url = args.url, let u = URL(string: url) {
        return OpenAIRunner(config: .init(
            baseURL: u,
            apiKey: args.key,
            model: args.model,
            contextLength: 8192
        ))
    }
    switch args.backend {
    case "llamacpp":
        return OpenAIRunner(config: .init(
            baseURL: URL(string: "http://localhost:\(args.port)")!,
            apiKey: args.key,
            model: args.model
        ))
    case "lmstudio":
        return OpenAIRunner(config: .init(
            baseURL: URL(string: "http://localhost:\(args.port)/v1")!,
            apiKey: args.key ?? "lm-studio",
            model: args.model
        ))
    case "ollama", "custom", _:
        return OpenAIRunner(config: .init(
            baseURL: URL(string: "http://localhost:\(args.port)/api")!,
            apiKey: args.key ?? "ollama",
            model: args.model
        ))
    }
}

// MARK: - 主循环
@main
struct Main {
    static func main() async {
        let argv = Array(CommandLine.arguments.dropFirst())
        let args = parseArgs(argv)

        if args.help {
            showHelp()
            return
        }

        print("""
        ╔══════════════════════════════════════════════════╗
        ║           mini-ai-cli — Local AI Agent           ║
        ╚══════════════════════════════════════════════════╝
        Backend: \(args.backend)
        Model:   \(args.model)
        URL:     \(args.url ?? "http://localhost:\(args.port)")
        """)

        let runner = makeRunner(args)
        let engine = ChatEngine(
            runner: runner,
            maxToolRounds: args.maxRounds
        )
        engine.loadStandardTools(braveAPIKey: args.braveKey)

        print("Tools loaded: \(engine.toolNames.joined(separator: ", "))")
        print("Type /help for commands, /exit to quit")
        print("---")

        await chatLoop(engine: engine)
    }

    static func chatLoop(engine: ChatEngine) async {
        while true {
            print("\nYou> ", terminator: "")
            guard let line = readLine() else {
                print("\nBye.")
                return
            }
            let input = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if input.isEmpty { continue }

            switch input.lowercased() {
            case "/exit", "/quit", "exit", "quit":
                print("Bye.")
                return
            case "/help":
                print("""
                /help     Show this
                /reset    Clear chat history
                /tools    List loaded tools
                /history  Show message count
                /exit     Quit
                """)
                continue
            case "/reset":
                engine.reset()
                print("History cleared.")
                continue
            case "/tools":
                for (i, t) in engine.toolNames.enumerated() {
                    print("  \(i+1). \(t)")
                }
                continue
            case "/history":
                print("  messages: \(engine.history.count)")
                continue
            default:
                print("Thinking...", terminator: "")
                do {
                    let reply = try await engine.chat(
                        userMessage: input,
                        onToolCall: { id, name in
                            print("\n  🔧 Tool: \(name) [\(id.prefix(8))]")
                        },
                        onResult: { result in
                            print("  ✓ Result (\(result.count) chars)")
                        }
                    )
                    print("\nAI>  \(reply)\n")
                } catch {
                    print("\nError: \(error.localizedDescription)")
                }
            }
        }
    }
}
