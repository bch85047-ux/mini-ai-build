// ChatEngine.swift
// Author: 海鸥
// Purpose: Agent循环 - 工具调用+结果回传+终止条件

import Foundation

/// 对话引擎 - 管理消息历史、工具注册、循环
public final class ChatEngine {
    public let runner: ModelRunner
    public let maxToolRounds: Int
    public let workspacePath: URL

    private var messages: [Message]
    private var tools: [Tool]
    private let toolMap: [String: Tool]

    public init(
        runner: ModelRunner,
        workspace: URL? = nil,
        maxToolRounds: Int = 8,
        systemPrompt: String = SystemPrompts.base
    ) {
        self.runner = runner
        self.maxToolRounds = maxToolRounds
        self.workspacePath = workspace ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]

        self.messages = [.system(systemPrompt)]
        self.tools = []
        self.toolMap = [:]
    }

    /// 添加工具
    public func register(_ tool: Tool) {
        tools.append(tool)
        toolMap[tool.name] = tool
    }

    /// 批量添加
    public func registerAll(_ tools: [Tool]) {
        for t in tools {
            register(t)
        }
    }

    /// 预设工具包
    public func loadStandardTools(braveAPIKey: String? = nil) {
        register(SearchTool(braveAPIKey: braveAPIKey))
        register(FileTool(workspace: workspacePath))
        register(ShellTool(workdir: workspacePath))
    }

    /// 清空历史，保留system
    public func reset() {
        let sys = messages.filter { $0.role == .system }
        messages = sys.isEmpty ? [.system(SystemPrompts.base)] : sys
    }

    /// 设置system prompt
    public func setSystem(_ text: String) {
        messages.removeAll { $0.role == .system }
        messages.insert(.system(text), at: 0)
    }

    /// 获取当前历史（copy）
    public var history: [Message] { messages }

    /// 追加用户消息
    public func addUser(_ text: String) {
        messages.append(.user(text))
    }

    /// 一次完整对话轮次 - 自动处理工具调用循环
    @discardableResult
    public func chat(
        userMessage: String,
        temperature: Double? = nil,
        maxTokens: Int? = nil,
        onToolCall: ((String, String) -> Void)? = nil,
        onResult: ((String) -> Void)? = nil
    ) async throws -> String {
        messages.append(.user(userMessage))

        var round = 0
        while round < maxToolRounds {
            round += 1
            let defs = tools.map { $0.definition }
            let output = try await runner.generate(
                messages: messages,
                tools: runner.supportsTools ? defs : nil,
                temperature: temperature,
                maxTokens: maxTokens,
                topP: nil
            )

            // 有tool_call → 执行 → 回传 → 继续
            if let calls = output.toolCalls, !calls.isEmpty {
                messages.append(.assistantToolCall(calls))
                for call in calls {
                    onToolCall?(call.id, call.function.name)
                    let result = await executeTool(call: call)
                    onResult?(result)
                    messages.append(.tool(result, forID: call.id))
                }
                continue
            }

            // 最终文本输出
            let final = output.content ?? "(empty response)"
            messages.append(.assistant(final))
            return final
        }
        return "(max tool rounds \(maxToolRounds) reached)"
    }

    /// 执行单个tool_call
    private func executeTool(call: ToolCall) async -> String {
        guard let tool = toolMap[call.function.name] else {
            return "Error: unknown tool '\(call.function.name)'"
        }
        do {
            let args = parseArgs(call.function.arguments)
            let result = try await tool.execute(args)
            return result
        } catch {
            return "Error: \(error.localizedDescription)"
        }
    }

    /// 解析arguments JSON字符串为字典
    private func parseArgs(_ json: String) -> [String: Any] {
        guard !json.isEmpty,
              let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data),
              let dict = obj as? [String: Any] else {
            return [:]
        }
        return dict
    }

    /// 获取工具定义列表
    public var toolDefinitions: [ToolDefinition] {
        tools.map { $0.definition }
    }

    /// 可用工具名
    public var toolNames: [String] {
        tools.map { $0.name }
    }
}
