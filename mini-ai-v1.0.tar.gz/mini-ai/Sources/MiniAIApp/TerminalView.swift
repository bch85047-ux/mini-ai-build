// TerminalView.swift
// 内置终端 - 完整版

import SwiftUI
import MiniAICore

struct TerminalView: View {
    @EnvironmentObject var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @StateObject private var executor = ShellExecutor()
    @State private var input = ""
    @State private var showSuggestions = false
    @State private var suggestions: [String] = []
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 终端输出区
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 3) {
                            // 欢迎横幅
                            terminalBanner()
                            
                            // 命令输出
                            ForEach(Array(executor.output.split(separator: "\n").enumerated()), id: \.offset) { _, line in
                                Text(String(line).isEmpty ? " " : String(line))
                                    .font(.system(.caption, design: .monospaced))
                                    .foregroundColor(terminalColor(for: String(line)))
                            }
                            
                            // 自动完成建议
                            if showSuggestions && !suggestions.isEmpty {
                                VStack(alignment: .leading, spacing: 2) {
                                    ForEach(suggestions, id: \.self) { suggestion in
                                        Text("  " + suggestion)
                                            .font(.system(.caption2, design: .monospaced))
                                            .foregroundColor(.yellow)
                                            .opacity(0.7)
                                    }
                                }
                            }
                            
                            // 光标
                            HStack(spacing: 2) {
                                Text("> ")
                                    .foregroundColor(.green)
                                CursorView()
                            }
                            .font(.system(.caption, design: .monospaced))
                            .id("cursor")
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.black)
                    }
                    .onChange(of: executor.output) { _ in
                        withAnimation(.easeOut(duration: 0.2)) {
                            proxy.scrollTo("cursor", anchor: .bottom)
                        }
                    }
                }
                
                Divider()
                
                // 快捷命令栏
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        quickButton("help", color: .blue) { execute("help") }
                        quickButton("status", color: .green) { execute("status") }
                        quickButton("setup", color: .orange) { execute("setup") }
                        quickButton("start", color: .red) { execute("start") }
                        quickButton("stop", color: .gray) { execute("stop") }
                        quickButton("models", color: .purple) { execute("models") }
                        quickButton("ip", color: .cyan) { execute("ip") }
                        quickButton("test", color: .pink) { execute("test") }
                        quickButton("demo", color: .indigo) { execute("demo") }
                        quickButton("clear", color: .secondary) { executor.clear() }
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 8)
                    .background(Color(.secondarySystemBackground))
                }
                
                // 输入框
                HStack(spacing: 8) {
                    Text(">")
                        .foregroundColor(.green)
                        .font(.system(.body, design: .monospaced))
                    
                    TextField("输入命令...", text: $input)
                        .font(.system(.body, design: .monospaced))
                        .autocorrectionDisabled()
                        .autocapitalization(.none)
                        .onSubmit { sendCommand() }
                        .onChange(of: input) { newValue in
                            updateSuggestions(newValue)
                        }
                    
                    Button {
                        sendCommand()
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title2)
                            .foregroundColor(.green)
                    }
                }
                .padding(12)
                .background(Color(.secondarySystemBackground))
            }
            .navigationTitle("内置终端")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        executor.clear()
                    } label: {
                        Image(systemName: "trash")
                            .foregroundColor(.secondary)
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
    }
    
    private func terminalBanner() -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("╔═══════════════════════════════════════════╗")
            Text("║  MiniAI 内置终端 v2.0                    ║")
            Text("║  状态: \(executor.serverStatus)                    ║")
            Text("║  模型: \(executor.modelLoaded ? "已加载" : "未加载")                    ║")
            Text("╚═══════════════════════════════════════════╝")
            Text("")
            Text("输入 'help' 查看命令")
        }
        .font(.system(.caption, design: .monospaced))
        .foregroundColor(.green)
    }
    
    private func terminalColor(for line: String) -> Color {
        if line.contains("╔") || line.contains("╠") || line.contains("╚") || line.contains("═") || line.contains("║") {
            return .green
        } else if line.contains("✓") {
            return .green
        } else if line.contains("✗") || line.contains("错误") {
            return .red
        } else if line.contains("$") {
            return .white
        } else if line.contains("📊") || line.contains("🛠️") || line.contains("🚀") || line.contains("🛑") || line.contains("🔄") || line.contains("📦") || line.contains("⬇️") || line.contains("🌐") || line.contains("🧪") || line.contains("🎭") || line.contains("📜") {
            return .yellow
        } else {
            return .white
        }
    }
    
    private func quickButton(_ title: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .fontWeight(.medium)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(color)
                .foregroundColor(.white)
                .cornerRadius(6)
        }
        .buttonStyle(.plain)
    }
    
    private func execute(_ cmd: String) {
        input = cmd
        executor.execute(command: cmd)
    }
    
    private func sendCommand() {
        let cmd = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cmd.isEmpty else { return }
        
        input = ""
        showSuggestions = false
        executor.execute(command: cmd)
    }
    
    private func updateSuggestions(_ partial: String) {
        let lower = partial.lowercased()
        guard !lower.isEmpty else {
            showSuggestions = false
            suggestions = []
            return
        }
        
        let matches = executor.availableCommands().filter { $0.hasPrefix(lower) }
        suggestions = matches.prefix(5).map { $0 }
        showSuggestions = !matches.isEmpty
    }
}

// 闪烁光标
struct CursorView: View {
    @State private var visible = true
    
    var body: some View {
        Text("|")
            .foregroundColor(.green)
            .opacity(visible ? 1 : 0)
            .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: visible)
            .onAppear {
                visible = true
                Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                    visible.toggle()
                }
            }
    }
}

// 终端行显示
extension TerminalView {
    func terminalLine(_ text: String) -> some View {
        Text(text.isEmpty ? " " : text)
            .font(.system(.caption, design: .monospaced))
            .foregroundColor(terminalColor(for: text))
    }
}

// String 扩展 - 填充字符串
extension String {
    func pad(toLength: Int, withSpace: Character = " ") -> String {
        if count >= toLength { return self }
        return self + String(repeating: String(withSpace), count: toLength - count)
    }
}
