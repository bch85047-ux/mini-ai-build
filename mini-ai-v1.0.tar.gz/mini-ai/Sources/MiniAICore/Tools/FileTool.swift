// FileTool.swift
// Author: 海鸥
// Purpose: 文件读写 + 24h过期清理

import Foundation

public final class FileTool: Tool {
    public let name = "file_ops"
    public let description = "Read, write, list, delete files in workspace."
    public let parameters: [String: ToolParameter]

    private let workspace: URL
    private let tempDir: URL
    private let expirySeconds: Int64 = 86400

    public init(workspace: URL? = nil) {
        self.parameters = [
            "action": ToolParameter(type: .string, description: "read|write|list|delete|info", `enum`: ["read","write","list","delete","info"]),
            "path": ToolParameter(type: .string, description: "Relative path."),
            "content": ToolParameter(type: .string, description: "Content for write.", required: false)
        ]
        let defaultWS = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("MiniAIWorkspace", isDirectory: true)
        let ws = workspace ?? defaultWS
        self.workspace = ws
        self.tempDir = ws.appendingPathComponent("temp", isDirectory: true)
        ensureDirs()
        cleanupExpired()
    }

    public var workspacePath: String { workspace.path }

    private func ensureDirs() {
        try? FileManager.default.createDirectory(at: workspace, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)
    }

    public func cleanupExpired() {
        let fm = FileManager.default
        let cutoff = Date().addingTimeInterval(-Double(expirySeconds))
        let keys: Set<URLResourceKey> = Set([URLResourceKey.contentModificationDateKey, URLResourceKey.fileSizeKey])
        guard let items = try? fm.contentsOfDirectory(at: tempDir, includingPropertiesForKeys: keys) else { return }
        for url in items {
            guard let mtime = try? url.resourceValues(forKeys: keys).contentModificationDate else { continue }
            if mtime < cutoff { try? fm.removeItem(at: url) }
        }
    }

    public func execute(_ args: [String: Any]) async throws -> String {
        guard let action = args["action"] as? String else { return "Error: action required" }
        let path = args["path"] as? String ?? ""
        guard isSafePath(path) else { return "Error: unsafe path" }
        switch action {
        case "write": return try write(path: path, content: args["content"] as? String)
        case "read": return try read(path: path)
        case "list": return list(path: path)
        case "delete": return try delete(path: path)
        case "info": return info(path: path)
        default: return "Error: unknown action"
        }
    }

    private func isSafePath(_ path: String) -> Bool {
        if path.hasPrefix("/") { return false }
        if path.contains("..") { return false }
        return workspace.appendingPathComponent(path).standardized.path.hasPrefix(workspace.standardized.path)
    }

    private func write(path: String, content: String?) throws -> String {
        guard let content else { return "Error: content required" }
        let url = workspace.appendingPathComponent(path)
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try content.write(to: url, atomically: true, encoding: .utf8)
        return "Written \(content.count) chars to \(path)"
    }

    private func read(path: String) throws -> String {
        let url = workspace.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else { return "Error: not found" }
        return try String(contentsOf: url, encoding: .utf8)
    }

    private func list(path: String) -> String {
        let dir = path.isEmpty ? workspace : workspace.appendingPathComponent(path)
        let keys: Set<URLResourceKey> = Set([URLResourceKey.fileSizeKey, URLResourceKey.contentModificationDateKey, URLResourceKey.isDirectoryKey])
        guard let items = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys) else {
            return "Error: cannot list"
        }
        var lines = ["Workspace: \(workspace.path)", "Dir: \(path)", ""]
        for url in items.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            let props = try? url.resourceValues(forKeys: keys)
            let isDir = props?.isDirectory ?? false
            let size = props?.fileSize ?? 0
            lines.append(isDir ? "D/ \(url.lastPathComponent)/" : "F/ \(url.lastPathComponent) (\(size)B)")
        }
        return lines.joined(separator: "\n")
    }

    private func delete(path: String) throws -> String {
        let url = workspace.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else { return "Error: not found" }
        try FileManager.default.removeItem(at: url)
        return "Deleted: \(path)"
    }

    private func info(path: String) -> String {
        let url = workspace.appendingPathComponent(path)
        guard let props = try? FileManager.default.attributesOfItem(atPath: url.path) else { return "Error: not found" }
        let size = props[.size] as? Int ?? 0
        return "Path: \(path)\nSize: \(size) bytes"
    }
}
