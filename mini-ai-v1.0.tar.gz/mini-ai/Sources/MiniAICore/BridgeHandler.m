// BridgeHandler.m
#import "BridgeHandler.h"
#import <Foundation/Foundation.h>

@implementation BridgeHandler

+ (void)executeCommand:(NSString *)command {
    NSLog(@"Command: %@", command);
    
    // 模拟执行命令
    if ([command isEqualToString:@"status"]) {
        NSLog(@"IP: 192.168.1.100");
        NSLog(@"Port: 11434");
    } else if ([command isEqualToString:@"setup"]) {
        NSLog(@"Running setup...");
    }
}

@end
