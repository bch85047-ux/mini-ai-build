#!/usr/bin/env bash
# setup.sh
# Author: 海鸥
# Purpose: 一键初始化环境 + 模型 + 运行

set -euo pipefail

MODEL="${1:-qwen2.5:7b-instruct}"
BACKEND="${2:-ollama}"

echo "════════════════════════════════════════"
echo "  MiniAI 环境初始化"
echo "  Model: $MODEL"
echo "  Backend: $BACKEND"
echo "════════════════════════════════════════"

# Step 1: 检查Xcode
if ! command -v swift &> /dev/null; then
    echo "[!] 未找到Swift编译器"
    echo "    安装Xcode: https://developer.apple.com/xcode/"
    exit 1
fi
echo "[✓] Swift: $(swift --version | head -1)"

# Step 2: 安装Ollama (如需要)
if [ "$BACKEND" = "ollama" ] && ! command -v ollama &> /dev/null; then
    echo "[!] 未找到Ollama"
    if command -v brew &> /dev/null; then
        read -p "用brew安装Ollama? [y/N] " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            brew install ollama
        else
            echo "[!] 请手动安装Ollama: brew install ollama"
            exit 1
        fi
    else
        echo "[!] 没有brew，请手动安装Ollama: https://ollama.com/download"
        exit 1
    fi
fi

# Step 3: 启动Ollama服务
if [ "$BACKEND" = "ollama" ]; then
    if ! pgrep -x ollama &> /dev/null; then
        echo "[*] 启动Ollama服务..."
        ollama serve > /tmp/ollama.log 2>&1 &
        sleep 3
    fi
    echo "[✓] Ollama运行中"
fi

# Step 4: 下载模型
if [ "$BACKEND" = "ollama" ]; then
    if ollama list 2>/dev/null | grep -q "^$MODEL"; then
        echo "[✓] 模型 $MODEL 已下载"
    else
        echo "[*] 下载模型 $MODEL (约4-8GB，可能需要几分钟)..."
        ollama pull "$MODEL"
    fi
fi

# Step 5: 编译CLI
echo "[*] 编译CLI..."
cd "$(dirname "$0")"
swift build 2>&1 | tail -20

# Step 6: 启动
echo "════════════════════════════════════════"
echo "  准备就绪！"
echo "════════════════════════════════════════"
swift run mini-ai-cli \
    --backend "$BACKEND" \
    --model "$MODEL" \
    --port 11434
