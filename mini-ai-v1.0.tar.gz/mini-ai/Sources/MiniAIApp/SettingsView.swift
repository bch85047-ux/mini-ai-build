// SettingsView.swift
// Author: 海鸥
// Purpose: 设置界面 - 后端配置/系统提示词/BraveKey

import SwiftUI
import MiniAICore

struct SettingsView: View {
    @EnvironmentObject var settings: AppSettings

    var body: some View {
        NavigationStack {
            Form {
                Section("模型后端") {
                    Picker("后端", selection: $settings.backend) {
                        Text("Ollama").tag("ollama")
                        Text("llama.cpp server").tag("llamacpp")
                        Text("LM Studio").tag("lmstudio")
                        Text("自定义URL").tag("custom")
                    }
                    TextField("服务器IP", text: $settings.serverIP)
                        .keyboardType(.numbersAndPunctuation)
                    TextField("端口", value: $settings.port, format: .number)
                        .keyboardType(.numberPad)
                    TextField("模型名称", text: $settings.model)
                        .autocorrectionDisabled()
                }

                Section("生成参数") {
                    Slider(value: $settings.temperature, in: 0...1.5, step: 0.1) {
                        Text("温度")
                    } minimumValueLabel: {
                        Text("0")
                    } maximumValueLabel: {
                        Text("1.5")
                    }
                    Text("温度: \(settings.temperature, specifier: "%.1f")")
                        .font(.caption).foregroundStyle(.secondary)

                    Stepper("最大工具轮数: \(settings.maxRounds)",
                            value: $settings.maxRounds, in: 1...16)
                }

                Section("搜索") {
                    SecureField("Brave Search API Key (可选)", text: $settings.braveKey)
                    Text("空则回退到Wikipedia/Bing抓取。申请: https://brave.com/search/api/")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section("系统提示词") {
                    TextEditor(text: $settings.systemPrompt)
                        .frame(height: 160)
                        .font(.system(.body, design: .monospaced))
                    Button("重置为默认") {
                        settings.systemPrompt = SystemPrompts.base
                    }
                }

                Section("关于") {
                    Text("MiniAI v1.0")
                    Text("本地AI Agent，无审查，支持联网搜索、文件读写、24h自动清理")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
        }
    }
}
