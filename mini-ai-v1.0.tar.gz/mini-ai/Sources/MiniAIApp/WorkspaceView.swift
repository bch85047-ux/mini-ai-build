// WorkspaceView.swift
// Author: 海鸥
// Purpose: 工作区浏览器 + 24h清理状态

import SwiftUI
import UniformTypeIdentifiers
import MiniAICore

struct WorkspaceView: View {
    @State private var files: [FileItem] = []
    @State private var currentPath = ""
    @State private var showDetail = false
    @State private var selectedFile: FileItem?
    @State private var showEditor = false
    @State private var editorText = ""
    @State private var refreshID = UUID()
    @StateObject private var fileTool = FileToolHolder()

    var body: some View {
        NavigationStack {
            List {
                Section("工作区: \(fileTool.workspacePath)") {
                    Button {
                        refresh()
                    } label: {
                        Label("刷新", systemImage: "arrow.clockwise")
                    }
                    Button {
                        Task { await fileTool.runCleanup() }
                        refresh()
                    } label: {
                        Label("清理过期文件 (24h+)", systemImage: "trash")
                    }
                }

                Section("目录: \(currentPath.isEmpty ? "根目录" : currentPath)") {
                    ForEach(files) { item in
                        FileRowView(item: item) {
                            open(item: item)
                        }
                        .swipeActions {
                            Button(role: .destructive) {
                                delete(item: item)
                            } label: {
                                Label("删除", systemImage: "trash")
                            }
                        }
                    }
                    if files.isEmpty {
                        Text("(空目录)")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("工作区")
            .id(refreshID)
            .onAppear { refresh() }
            .sheet(isPresented: $showDetail) {
                if let sel = selectedFile {
                    FileDetailSheet(item: sel, onClose: { showDetail = false })
                }
            }
            .sheet(isPresented: $showEditor) {
                FileEditorSheet(initialText: editorText, filePath: selectedFile?.path ?? "", onSave: { text in
                    _ = fileTool.writeFile(path: selectedFile?.path ?? "", content: text)
                    showEditor = false
                    refresh()
                })
            }
        }
    }

    private func refresh() {
        let result = fileTool.list(path: currentPath)
        files = parseList(result)
        refreshID = UUID()
    }

    private func open(item: FileItem) {
        selectedFile = item
        if item.isDirectory {
            currentPath = item.path
            refresh()
        } else {
            // 文本文件可编辑
            let content = fileTool.readFile(path: item.path)
            editorText = content.isEmpty ? "" : content
            showEditor = true
        }
    }

    private func delete(item: FileItem) {
        _ = fileTool.delete(path: item.path)
        refresh()
    }

    private func parseList(_ result: String) -> [FileItem] {
        var items: [FileItem] = []
        let lines = result.components(separatedBy: "\n")
        for line in lines {
            if line.hasPrefix("📁") || line.hasPrefix("📄") {
                let content = String(line.dropFirst(2)).trimmingCharacters(in: .whitespaces)
                if let spaceIdx = content.firstIndex(of: " ") {
                    let name = String(content[..<spaceIdx])
                    let isDir = line.hasPrefix("📁")
                    let fullPath = currentPath.isEmpty ? name : "\(currentPath)/\(name)"
                    items.append(FileItem(name: name, path: fullPath, isDirectory: isDir))
                }
            }
        }
        // 添加"返回上级"
        if !currentPath.isEmpty {
            items.insert(FileItem(name: "⬆️ 上级", path: "..", isDirectory: true), at: 0)
        }
        return items
    }
}

struct FileToolHolder: ObservableObject {
    let tool = FileTool()
    var workspacePath: String { tool.workspacePath }

    func list(path: String) -> String {
        let sem = DispatchSemaphore(value: 0)
        var result = ""
        Task {
            result = (try? await tool.execute([
                "action": "list",
                "path": path
            ])) ?? "Error"
            sem.signal()
        }
        sem.wait()
        return result
    }

    func readFile(path: String) -> String {
        let sem = DispatchSemaphore(value: 0)
        var result = ""
        Task {
            result = (try? await tool.execute([
                "action": "read",
                "path": path
            ])) ?? "Error"
            sem.signal()
        }
        sem.wait()
        return result
    }

    func writeFile(path: String, content: String) -> String {
        let sem = DispatchSemaphore(value: 0)
        var result = ""
        Task {
            result = (try? await tool.execute([
                "action": "write",
                "path": path,
                "content": content
            ])) ?? "Error"
            sem.signal()
        }
        sem.wait()
        return result
    }

    func delete(path: String) -> String {
        let sem = DispatchSemaphore(value: 0)
        var result = ""
        Task {
            result = (try? await tool.execute([
                "action": "delete",
                "path": path
            ])) ?? "Error"
            sem.signal()
        }
        sem.wait()
        return result
    }

    func runCleanup() {
        tool.cleanupExpired()
    }
}

struct FileItem: Identifiable {
    let id = UUID()
    let name: String
    let path: String
    let isDirectory: Bool
}

struct FileRowView: View {
    let item: FileItem
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack {
                Image(systemName: item.isDirectory ? "folder" : "doc")
                    .foregroundStyle(item.isDirectory ? .blue : .gray)
                Text(item.name)
                Spacer()
                if item.path == ".." {
                    Text("上级").font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

struct FileDetailSheet: View {
    let item: FileItem
    let onClose: () -> Void

    var body: some View {
        NavigationStack {
            Text(item.path)
                .font(.caption)
                .padding()
            Text("路径: \(item.path)")
            Text("类型: \(item.isDirectory ? "目录" : "文件")")
        }
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("关闭") { onClose() }
            }
        }
    }
}

struct FileEditorSheet: View {
    let initialText: String
    let filePath: String
    let onSave: (String) -> Void
    @State private var text = ""

    var body: some View {
        NavigationStack {
            VStack {
                TextField("路径: \(filePath)", text: .constant(filePath))
                    .font(.caption2).foregroundStyle(.secondary)
                TextEditor(text: $text)
                    .font(.system(.body, design: .monospaced))
            }
            .padding()
            .navigationTitle("编辑")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        onSave(text)
                        dismiss()
                    }
                }
            }
            .onAppear { text = initialText }
        }
    }

    @Environment(\.dismiss) private var dismiss
}
