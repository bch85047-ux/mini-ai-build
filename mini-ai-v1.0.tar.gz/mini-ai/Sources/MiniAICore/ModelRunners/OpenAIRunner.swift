// OpenAIRunner.swift
// Author: 海鸥
// Purpose: OpenAI-compatible API客户端 - 兼容Ollama/llama.cpp/LM Studio/vLLM

import Foundation

/// OpenAI-compatible API推理后端
/// 支持：Ollama, llama.cpp server, LM Studio, vLLM, LocalAI, SenseNova, 以及所有OpenAI兼容API
public final class OpenAIRunner: ModelRunner {
    public let modelID: String
    public let contextLength: Int
    public let supportsTools: Bool

    private let baseURL: URL
    private let apiKey: String?
    private let session: URLSession
    private let timeout: Int64
    private let temperature: Double
    private let topP: Double
    private let maxTokens: Int

    public init(config: RunnerConfig, supportsTools: Bool = true) {
        self.baseURL = config.baseURL
        self.apiKey = config.apiKey
        self.modelID = config.model
        self.contextLength = config.contextLength
        self.timeout = config.timeout
        self.temperature = config.temperature
        self.topP = config.topP
        self.maxTokens = config.maxTokens
        self.supportsTools = supportsTools

        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = TimeInterval(config.timeout)
        cfg.timeoutIntervalForResource = TimeInterval(config.timeout * 3)
        self.session = URLSession(configuration: cfg)
    }

    /// 常用工厂方法
    public static func ollama(model: String = "qwen2.5:7b", port: Int = 11434) -> OpenAIRunner {
        .init(config: .init(
            baseURL: URL(string: "http://localhost:\(port)/api")!,
            apiKey: "ollama",
            model: model,
            contextLength: 8192
        ))
    }

    public static func llamaCppServer(model: String = "qwen2.5-7b", port: Int = 8080) -> OpenAIRunner {
        .init(config: .init(
            baseURL: URL(string: "http://localhost:\(port)")!,
            apiKey: nil,
            model: model,
            contextLength: 8192
        ))
    }

    public static func lmsStudio(model: String = "qwen2.5-7b", port: Int = 1234) -> OpenAIRunner {
        .init(config: .init(
            baseURL: URL(string: "http://localhost:\(port)/v1")!,
            apiKey: "lm-studio",
            model: model,
            contextLength: 8192
        ))
    }

    public func generate(
        messages: [Message],
        tools: [ToolDefinition]?,
        temperature: Double?,
        maxTokens: Int?,
        topP: Double?
    ) async throws -> ModelOutput {
        let request = ChatRequest(
            model: modelID,
            messages: messages,
            tools: (supportsTools && tools?.isEmpty == false) ? tools : nil,
            temperature: temperature ?? self.temperature,
            maxTokens: maxTokens ?? self.maxTokens,
            topP: topP ?? self.topP,
            stream: false
        )

        let endpoint = baseURL.appendingPathComponent("chat/completions")
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let key = apiKey, !key.isEmpty {
            req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        }

        let encoder = JSONEncoder()
        let body = try encoder.encode(request)
        req.httpBody = body

        do {
            let (data, response) = try await session.data(for: req)
            guard let http = response as? HTTPURLResponse else {
                throw MiniAIError.networkError("invalid response")
            }
            if http.statusCode != 200 {
                let errText = String(data: data, encoding: .utf8) ?? "unknown"
                throw MiniAIError.networkError("HTTP \(http.statusCode): \(errText)")
            }
            return try parseResponse(data)
        } catch let e as MiniAIError {
            throw e
        } catch {
            throw MiniAIError.networkError(error.localizedDescription)
        }
    }

    private func parseResponse(_ data: Data) throws -> ModelOutput {
        // OpenAI标准格式
        let decoder = JSONDecoder()
        struct ResponseEnvelope: Decodable {
            let choices: [Choice]
            struct Choice: Decodable {
                let message: MessagePayload
                struct MessagePayload: Decodable {
                    let role: Role
                    let content: String?
                    let toolCalls: [ToolCall]?
                }
            }
        }

        do {
            let env = try decoder.decode(ResponseEnvelope.self, from: data)
            guard let first = env.choices.first else {
                throw MiniAIError.unexpectedResponse("no choices")
            }
            return .init(
                role: first.message.role,
                content: first.message.content,
                toolCalls: first.message.toolCalls
            )
        } catch {
            // 尝试解析streaming chunks 兼容
            throw MiniAIError.encodingError("Failed to parse: \(error.localizedDescription)")
        }
    }
}
