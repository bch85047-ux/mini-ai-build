// LocalSetupView.swift
// 本地模型设置页面

import SwiftUI
import MiniAICore

struct LocalSetupView: View {
    @EnvironmentObject var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State private var ipadIP = "192.168.1.100"
    @State private var serverRunning = false
    @State private var showModelInfo = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // 标题
                    VStack(spacing: 8) {
                        Image(systemName: "cpu")
                            .font(.system(size: 48))
                            .foregroundColor(.blue)
                        Text("本地模型设置")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("一键部署，无需 API")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 20)
                    
                    // Step 1: 检测 IP
                    setupCard {
                        Text("1. 获取 iPad IP")
                            .font(.headline)
                            .fontWeight(.semibold)
                    } content: {
                        VStack(spacing: 12) {
                            HStack {
                                Text("IP 地址:")
                                    .foregroundColor(.secondary)
                                TextField("192.168.1.100", text: $ipadIP)
                                    .font(.body)
                                    .textFieldStyle(.roundedBorder)
                            }
                            
                            Text("获取方法: 设置 → WiFi → 点击 ⓘ → IP 地址")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .padding(.vertical, 4)
                        }
                    }
                    
                    // Step 2: 部署服务器
                    setupCard {
                        Text("2. 部署 iSH 服务器")
                            .font(.headline)
                            .fontWeight(.semibold)
                    } content: {
                        VStack(spacing: 12) {
                            Text("在 iSH 中运行:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            CodeBlock(text: "sh /var/minis/workspace/setup-local-ai.sh")
                            
                            Button(action: { UIPasteboard.general.string = "sh /var/minis/workspace/setup-local-ai.sh" }) {
                                Label("复制命令", systemImage: "doc.on.doc")
                                    .font(.caption)
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    
                    // Step 3: 下载模型
                    setupCard {
                        Text("3. 下载无审查模型")
                            .font(.headline)
                            .fontWeight(.semibold)
                    } content: {
                        VStack(spacing: 12) {
                            Text("选择模型（点击下载链接）:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            ModelLink(name: "Qwen2.5-1.8B", desc: "中文优秀，推荐", url: "https://huggingface.co/QuantFactory/Qwen2.5-1.8B-Instruct-GGUF/resolve/main/qwen2.5-1.8b-instruct-q4_K_M.gguf")
                            ModelLink(name: "TinyLlama-1.1B", desc: "最小最快", url: "https://huggingface.co/QuantFactory/tinyllama-1.1b-chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0-q4_0.gguf")
                            ModelLink(name: "Phi-2-1.3B", desc: "英文优秀", url: "https://huggingface.co/QuantFactory/phi-2-GGUF/resolve/main/phi-2-q4_K_M.gguf")
                            ModelLink(name: "Gemma-2B", desc: "Google出品", url: "https://huggingface.co/QuantFactory/gemma-2b-it-GGUF/resolve/main/gemma-2b-it-q4_K_M.gguf")
                        }
                    }
                    
                    // Step 4: 配置 App
                    setupCard {
                        Text("4. 配置 App")
                            .font(.headline)
                            .fontWeight(.semibold)
                    } content: {
                        VStack(spacing: 12) {
                            HStack {
                                Text("配置:")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Spacer()
                                Button("自动配置") {
                                    settings.serverIP = ipadIP
                                    settings.port = 11434
                                    settings.backend = "ollama"
                                    settings.demoMode = false
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.green)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                ConfigRow(label: "后端", value: "ollama")
                                ConfigRow(label: "IP", value: ipadIP)
                                ConfigRow(label: "端口", value: "11434")
                                ConfigRow(label: "演示模式", value: "关闭")
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                        }
                    }
                    
                    // 快速启动
                    Button(action: {
                        UIPasteboard.general.string = "sh /var/minis/workspace/setup-local-ai.sh"
                    }) {
                        HStack {
                            Image(systemName: "play.circle.fill")
                                .font(.title2)
                            Text("复制启动命令")
                                .font(.headline)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .padding(.top, 10)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationTitle("本地模型")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
            }
        }
    }
    
    private func setupCard<Header: View, Content: View>(
        @ViewBuilder header: () -> Header,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            header()
            content()
        }
        .padding(16)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
    }
}

struct CodeBlock: View {
    let text: String
    @State private var copied = false
    
    var body: some View {
        HStack {
            Text(text)
                .font(.system(.caption, design: .monospaced))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(8)
                .background(Color(.tertiarySystemBackground))
                .cornerRadius(6)
            
            Button {
                UIPasteboard.general.string = text
                withAnimation { copied = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation { copied = false }
                }
            } label: {
                Image(systemName: copied ? "checkmark" : "doc.on.doc")
                    .font(.caption)
            }
        }
    }
}

struct ModelLink: View {
    let name: String
    let desc: String
    let url: String
    
    var body: some View {
        HStack {
            Image(systemName: "arrow.down.circle")
                .font(.title3)
                .foregroundColor(.blue)
            VStack(alignment: .leading, spacing: 2) {
                Text(name)
                    .font(.body)
                    .fontWeight(.medium)
                Text(desc)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Link("下载", destination: URL(string: url)!)
                .font(.caption)
                .tint(.blue)
        }
        .padding(10)
        .background(Color(.tertiarySystemBackground))
        .cornerRadius(8)
    }
}

struct ConfigRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
            Spacer()
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
        }
    }
}
