# MiniAI 快速开始（5分钟上手）

## 前置（一次性）

```bash
# 1. 安装Xcode (macOS)
# 2. 安装Ollama
brew install ollama
ollama serve &
# 3. 下载模型
ollama pull qwen2.5:7b-instruct
```

## 编译并运行CLI

```bash
cd mini-ai
swift run mini-ai-cli
```

## 交互

```
You> 你好
AI>  你好，我是MiniAI...

You> 帮我搜索今天的新闻
  🔧 Tool: web_search
  ✓ Result
AI>  今天的主要新闻有...

You> 保存到文件
  🔧 Tool: file_ops
  ✓ Written
AI>  已保存到 workspace/news.md
```

## 部署到iPad

```bash
# 1. 用project.yml生成xcodeproj
brew install xcodegen
cd mini-ai
xcodegen generate
open MiniAIApp.xcodeproj

# 2. 配置签名
# 3. Run到iPad
# 4. iPad设置里修改服务器IP为Mac地址
```

## 后端选择

- **纯Mac运行**：Mac开Ollama，iPad做UI，同WiFi
- **纯iPad运行**：需要本地LLM app（PocketPal AI）+ 自定义桥接
- **远程API**：改成云端OpenAI兼容API（如SenseNova、ChatGLM等）
