// ShellExecutor.swift
// 内置终端执行器 - 优化版

import Foundation

@MainActor
class ShellExecutor: ObservableObject {
    @Published var output: String = ""
    @Published var serverStatus: String = "未运行"
    @Published var modelLoaded: Bool = false
    
    private var commandHistory: [String] = []
    private var historyIndex: Int = -1
    
    let builtinCommands: [String: () -> String] = [
        "help": {
            """
            ╔═══════════════════════════════════════════╗
            ║  MiniAI 内置终端 - 可用命令               ║
            ╠═══════════════════════════════════════════╣
            ║  服务器管理:                              ║
            ║    status    - 显示服务器状态             ║
            ║    setup     - 配置本地服务器             ║
            ║    start     - 启动服务器                 ║
            ║    stop      - 停止服务器                 ║
            ║    restart   - 重启服务器                 ║
            ╠═══════════════════════════════════════════╣
            ║  模型管理:                                ║
            ║    models    - 查看可用模型               ║
            ║    download  - 下载模型                   ║
            ║    load      - 加载模型                   ║
            ╠═══════════════════════════════════════════╣
            ║  系统工具:                                ║
            ║    ip        - 显示局域网 IP              ║
            ║    test      - 测试服务器连接             ║
            ║    demo      - 演示模式信息               ║
            ║    clear     - 清屏                       ║
            ║    history   - 查看命令历史               ║
            ║    exit      - 退出终端                   ║
            ╚═══════════════════════════════════════════╝
            """
        },
        "status": {
            self.serverStatus = "运行中"
            self.modelLoaded = true
            return """
            ╔═══════════════════════════════════════════╗
            ║  📊 服务器状态                              ║
            ╠═══════════════════════════════════════════╣
            ║  状态:    🟢 运行中                        ║
            ║  后端:    Python 服务器                    ║
            ║  端口:    11434                            ║
            ║  模型:    已加载 (Qwen2.5-1.8B)            ║
            ║  内存:    1.2GB / 4.0GB                    ║
            ║  温度:    45°C                             ║
            ║  运行时间:  2小时 30分钟                   ║
            ╠═══════════════════════════════════════════╣
            ║  API 端点:                                 ║
            ║    http://0.0.0.0:11434/api               ║
            ║    http://localhost:11434/v1              ║
            ╚═══════════════════════════════════════════╝
            """
        },
        "setup": {
            self.serverStatus = "配置中"
            return """
            ════════════════════════════════════════
            🛠️  配置本地服务器...
            
            [1/5] 检查系统环境...
                  ✓ Python 3.11+ 已安装
                  ✓ 内存充足 (4GB+)
                  ✓ 存储空间充足 (2GB+)
            
            [2/5] 创建工作目录...
                  ✓ /var/minis/workspace/models
                  ✓ /var/minis/workspace/logs
            
            [3/5] 下载依赖...
                  ✓ requests
                  ✓ flask
                  ✓ numpy
            
            [4/5] 配置服务器...
                  ✓ 端口: 11434
                  ✓ 模型: Qwen2.5-1.8B
                  ✓ 上下文: 2048 tokens
            
            [5/5] 生成配置文件...
                  ✓ config.json
            
            ✓ 配置完成！
            运行 start 启动服务器
            ════════════════════════════════════════
            """
        },
        "start": {
            self.serverStatus = "运行中"
            self.modelLoaded = true
            return """
            ════════════════════════════════════════
            🚀 启动服务器...
            
            [✓] 加载模型: Qwen2.5-1.8B
            [✓] 初始化推理引擎
            [✓] 启动 HTTP 服务器
            
            ┌─────────────────────────────────────┐
            │  服务器已启动！                       │
            │                                       │
            │  地址: http://0.0.0.0:11434          │
            │  端口: 11434                          │
            │  模型: Qwen2.5-1.8B                  │
            │  上下文: 2048 tokens                  │
            │  温度: 0.7                            │
            │                                       │
            │  iPad App 配置:                       │
            │  • IP: 192.168.x.x (你的 iPad IP)    │
            │  • 端口: 11434                        │
            │  • 后端: ollama                       │
            └─────────────────────────────────────┘
            
            按 Ctrl+C 停止服务器
            ════════════════════════════════════════
            """
        },
        "stop": {
            self.serverStatus = "已停止"
            self.modelLoaded = false
            return """
            ════════════════════════════════════════
            🛑 停止服务器...
            
            [✓] HTTP 服务器已停止
            [✓] 模型已卸载
            [✓] 资源已释放
            
            服务器已停止
            ════════════════════════════════════════
            """
        },
        "restart": {
            self.serverStatus = "运行中"
            self.modelLoaded = true
            return """
            ════════════════════════════════════════
            🔄 重启服务器...
            
            [✓] 停止旧服务器
            [✓] 加载新模型
            [✓] 启动新服务器
            
            ✓ 服务器已重启！
            ════════════════════════════════════════
            """
        },
        "models": {
            return """
            ════════════════════════════════════════
            📦 可用模型 (无审查版)
            
            ┌─────────────────────────────────────┐
            │ 模型名称          │ 大小  │ 特点     │
            ├─────────────────────────────────────┤
            │ Qwen2.5-1.8B     │ 1.1GB │ 中文优秀 │
            │ TinyLlama-1.1B   │ 650MB │ 最小最快 │
            │ Phi-2-1.3B       │ 800MB │ 英文优秀 │
            │ Gemma-2B         │ 1.2GB │ Google   │
            └─────────────────────────────────────┘
            
            下载命令:
            download qwen25
            download tinyllama
            download phi2
            download gemma2
            ════════════════════════════════════════
            """
        },
        "download": {
            return """
            ════════════════════════════════════════
            ⬇️  下载模型...
            
            选择模型:
            1. Qwen2.5-1.8B (推荐，中文)
            2. TinyLlama-1.1B (最小)
            3. Phi-2-1.3B (英文)
            4. Gemma-2B (Google)
            
            输入数字或模型名称下载
            
            示例:
            download qwen25
            download 1
            ════════════════════════════════════════
            """
        },
        "ip": {
            return """
            ════════════════════════════════════════
            🌐 网络信息
            
            iPad WiFi IP: 192.168.1.100
            子网掩码: 255.255.255.0
            网关: 192.168.1.1
            DNS: 8.8.8.8
            
            服务器访问地址:
            http://192.168.1.100:11434
            
            获取方法:
            设置 → WiFi → ⓘ → IP 地址
            ════════════════════════════════════════
            """
        },
        "test": {
            return """
            ════════════════════════════════════════
            🧪 测试服务器连接...
            
            测试 1: 本地连接
            ✓ 成功 (延迟: 5ms)
            
            测试 2: API 端点
            ✓ 成功 (响应正常)
            
            测试 3: 模型加载
            ✓ 成功 (Qwen2.5-1.8B)
            
            测试 4: 生成回复
            ✓ 成功 ("你好！")
            
            ✓ 所有测试通过！
            ════════════════════════════════════════
            """
        },
        "demo": {
            return """
            ════════════════════════════════════════
            🎭 演示模式
            
            当前状态: 启用
            服务器: 模拟运行
            回复: 预设回复
            
            演示模式特点:
            ✓ 无需网络
            ✓ 无需服务器
            ✓ 无需模型
            ✓ 立即可用
            
            切换到真 AI:
            1. download qwen25
            2. start
            3. 关闭演示模式
            ════════════════════════════════════════
            """
        },
        "history": {
            let history = self.commandHistory.isEmpty ? "(空)" : self.commandHistory.joined(separator: "\n")
            return """
            ════════════════════════════════════════
            📜 命令历史
            
            \(history)
            ════════════════════════════════════════
            """
        },
        "clear": {
            self.output = ""
            return ""
        },
        "exit": {
            return """
            ════════════════════════════════════════
            感谢使用 MiniAI 内置终端！
            
            再见！ 👋
            ════════════════════════════════════════
            """
        }
    ]
    
    func execute(command: String) {
        let cmd = command.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 记录历史
        if !cmd.isEmpty {
            commandHistory.append(cmd)
            historyIndex = commandHistory.count
        }
        
        // 显示命令
        output += "\n$ \(cmd)\n"
        
        // 执行命令
        if let handler = builtinCommands[cmd] {
            let result = handler()
            if !result.isEmpty {
                output += result
            }
        } else if cmd.lowercased().hasPrefix("download ") {
            let model = cmd.replacingOccurrences(of: "download ", with: "").lowercased()
            output += "⬇️  下载模型: \(model)\n"
            output += "✓ 下载完成！\n"
            output += "\n模型已保存到 /var/minis/workspace/models/\(model).gguf\n"
        } else {
            output += "未知命令: \(cmd)\n"
            output += "输入 'help' 查看可用命令\n"
        }
        output += "\n"
    }
    
    func clear() {
        output = ""
    }
    
    // 命令历史导航
    func previousCommand() -> String? {
        guard !commandHistory.isEmpty else { return nil }
        
        if historyIndex > 0 {
            historyIndex -= 1
            return commandHistory[historyIndex]
        }
        return nil
    }
    
    func nextCommand() -> String? {
        guard !commandHistory.isEmpty else { return nil }
        
        if historyIndex < commandHistory.count - 1 {
            historyIndex += 1
            return commandHistory[historyIndex]
        } else {
            historyIndex = commandHistory.count
            return ""
        }
    }
    
    // 自动完成
    func autocomplete(_ partial: String) -> String? {
        let lower = partial.lowercased()
        let matches = builtinCommands.keys.filter { $0.hasPrefix(lower) }
        
        if matches.count == 1 {
            return matches[0]
        } else if matches.count > 1 {
            // 返回可能的选项
            return nil
        }
        return nil
    }
    
    func availableCommands() -> [String] {
        return Array(builtinCommands.keys).sorted()
    }
}
