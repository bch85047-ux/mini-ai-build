// ShellTool.swift
// Author: 海鸥
// Purpose: 本地命令执行 - 只读优先，白名单保护

import Foundation

/// 命令执行工具，默认白名单安全模式
/// 白名单：cat, ls, pwd, echo, date, uname, which, head, tail, wc, grep, sed (只读)
public final class ShellTool: Tool {
    public let name = "shell_exec"
    public let description = "Execute a shell command. Restricted to safe read-only commands by default."
    public let parameters: [String: ToolParameter]

    private let workdir: URL
    private let allowedCommands: Set<String>
    private let allowAll: Bool
    private let timeout: Int64

    public init(
        workdir: URL? = nil,
        allowAll: Bool = false,
        timeout: Int64 = 15
    ) {
        self.workdir = workdir ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.allowAll = allowAll
        self.timeout = timeout
        self.parameters = [
            "command": ToolParameter(
                type: .string,
                description: "Shell command to execute. Read-only commands only unless allow_all."
            ),
            "workdir": ToolParameter(
                type: .string,
                description: "Working directory (default: app documents).",
                required: false
            )
        ]
    }

    private static let readonlyAllowlist: Set<String> = [
        "cat", "ls", "pwd", "echo", "date", "uname", "which", "whoami", "head", "tail", "wc", "grep",
        "find", "du", "df", "file", "stat", "sort", "uniq", "cut", "tr", "awk", "sed", "jq",
        "realpath", "basename", "dirname", "env", "printenv", "sha256sum", "md5sum", "xxd", "od"
    ]

    public func execute(_ args: [String: Any]) async throws -> String {
        guard let command = args["command"] as? String, !command.isEmpty else {
            return "Error: 'command' is required"
        }

        // 安全检查
        if !allowAll {
            let firstToken = command.split(separator: " ", omittingEmptySubsequences: true).first.map(String.init) ?? ""
            let base = (firstToken as NSString).lastPathComponent
            if !Self.readonlyAllowlist.contains(base) {
                return "Blocked: '\(base)' not in readonly allowlist. Enable allow_all for full shell access."
            }
            // 拒绝危险操作
            if command.contains("rm ") || command.contains("rm -") ||
               command.contains("mkfs") || command.contains("dd if=") ||
               command.contains("shutdown") || command.contains("reboot") {
                return "Blocked: destructive command"
            }
        }

        let cwd = (args["workdir"] as? String).map { workdir.appendingPathComponent($0) } ?? workdir
        guard FileManager.default.fileExists(atPath: cwd.path) else {
            return "Error: workdir not found: \(cwd.path)"
        }

        return await run(command: command, cwd: cwd)
    }

    private func run(command: String, cwd: URL) async -> String {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/bin/sh")
        process.arguments = ["-c", command]
        process.currentDirectoryURL = cwd

        let stdoutPipe = Pipe()
        let stderrPipe = Pipe()
        process.standardOutput = stdoutPipe
        process.standardError = stderrPipe

        var output = ""
        do {
            try process.run()
            // 等待进程结束，带超时
            let deadline = Date().addingTimeInterval(TimeInterval(timeout))
            while process.isRunning {
                if Date() > deadline {
                    process.terminate()
                    return "Error: command timed out after \(timeout)s"
                }
                Thread.sleep(forTimeInterval: 0.05)
            }
            let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
            let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()
            output += String(data: stdoutData, encoding: .utf8) ?? ""
            if let err = String(data: stderrData, encoding: .utf8), !err.isEmpty {
                output += "\n[stderr]\n" + err
            }
            if output.count > 100_000 {
                output = String(output.prefix(100_000)) + "\n... [truncated]"
            }
            return output.isEmpty ? "(no output, exit \(process.terminationStatus))" : output
        } catch {
            return "Error running command: \(error.localizedDescription)"
        }
    }
}
