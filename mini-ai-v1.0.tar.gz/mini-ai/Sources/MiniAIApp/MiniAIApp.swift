// MiniAIApp.swift
// Author: 海鸥
// Purpose: iPad App入口

import SwiftUI

@main
struct MiniAIApp: App {
    @StateObject private var settings = AppSettings()
    @AppStorage("setup_completed") private var setupCompleted = true

    var body: some Scene {
        WindowGroup {
            if setupCompleted {
                RootView()
                    .environmentObject(settings)
            } else {
                SetupWizard()
                    .environmentObject(settings)
                    .environment(\.setupCompleted, .constant(false))
            }
        }
    }
}

struct RootView: View {
    @EnvironmentObject var settings: AppSettings
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            ChatView()
                .tabItem { Label("聊天", systemImage: "bubble.left.and.bubble.right") }
                .tag(0)
            WorkspaceView()
                .tabItem { Label("文件", systemImage: "folder") }
                .tag(1)
            SettingsView()
                .tabItem { Label("设置", systemImage: "gear") }
                .tag(2)
        }
    }
}

// MARK: - 首次启动向导

struct SetupWizard: View {
    @EnvironmentObject var settings: AppSettings
    @AppStorage("setup_completed") private var setupCompleted = true
    @State private var step = 0
    @State private var isTesting = false
    @State private var testResult: String? = nil
    @State private var showKeyInfo = false
    
    var body: some View {
        VStack(spacing: 20) {
            // 标题
            VStack(spacing: 8) {
                Image(systemName: "sparkles")
                    .font(.system(size: 60))
                    .foregroundColor(.blue)
                Text("欢迎使用 MiniAI")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Text("三步完成配置")
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
            .padding(.top, 40)
            
            Spacer()
            
            // 步骤指示器
            HStack(spacing: 10) {
                ForEach(0..<3, id: \.self) { i in
                    Circle()
                        .fill(i <= step ? .blue : .gray.opacity(0.3))
                        .frame(width: 12, height: 12)
                }
            }
            
            Spacer()
            
            // 步骤内容
            Group {
                if step == 0 {
                    backendStep
                } else if step == 1 {
                    apiKeyStep
                } else if step == 2 {
                    testStep
                }
            }
            
            Spacer()
            
            // 底部按钮
            HStack {
                if step > 0 {
                    Button("上一步") { step -= 1 }
                        .foregroundColor(.secondary)
                }
                Spacer()
                Button(step < 2 ? "下一步" : "开始使用") {
                    if step < 2 {
                        step += 1
                    } else {
                        setupCompleted = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(step == 1 && settings.apiKey.isEmpty && needsKey)
            }
        }
        .padding(32)
        .alert("如何获取 API Key", isPresented: $showKeyInfo) {
            Button("知道了") {}
        } message: {
            Text(keyInfoMessage)
        }
    }
    
    // 步骤1: 选择后端
    private var backendStep: some View {
        VStack(spacing: 16) {
            Text("选择 AI 后端")
                .font(.title2)
                .fontWeight(.semibold)
            
            ScrollView {
                VStack(spacing: 12) {
                    ForEach(AppSettings.backends, id: \.name) { backend in
                        Button(action: { settings.backend = backend.name; settings.model = backend.defaultModel }) {
                            HStack {
                                Image(systemName: backendIcon(backend.name))
                                    .font(.title2)
                                    .frame(width: 40)
                                VStack(alignment: .leading) {
                                    Text(backend.displayName)
                                        .font(.headline)
                                    Text(backend.defaultModel)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                if settings.backend == backend.name {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding(16)
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(settings.backend == backend.name ? Color.blue : .clear, lineWidth: 2)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .frame(maxHeight: 400)
        }
    }
    
    // 步骤2: 输入API Key
    private var apiKeyStep: some View {
        VStack(spacing: 16) {
            Text("输入 API Key")
                .font(.title2)
                .fontWeight(.semibold)
            
            if needsKey {
                VStack(spacing: 12) {
                    SecureField("输入 \(currentBackendName) API Key", text: $settings.apiKey)
                        .padding(12)
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(10)
                        .keyboardType(.asciiCapable)
                        .textInputAutocapitalization(.never)
                    
                    Button(action: { showKeyInfo = true }) {
                        Label("如何获取?", systemImage: "info.circle")
                    }
                    .foregroundColor(.blue)
                    .font(.caption)
                    
                    Text("免费选项: Groq 提供 \(currentBackendName == "Groq" ? "免费额度" : "免费API")")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "checkmark.circle")
                        .font(.system(size: 48))
                        .foregroundColor(.green)
                    Text("\(currentBackendName) 不需要 API Key")
                        .font(.headline)
                    Text("确保服务器已在 IP: \(settings.serverIP):\(settings.port) 启动")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        TextField("IP", text: $settings.serverIP, prompt: Text("192.168.1.100"))
                        TextField("端口", text: $settings.port, value: $settings.port, formatter: NumberFormatter())
                    }
                    .padding(12)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(10)
                    .frame(maxWidth: 300)
                }
            }
        }
    }
    
    // 步骤3: 测试连接
    private var testStep: some View {
        VStack(spacing: 20) {
            Text("测试连接")
                .font(.title2)
                .fontWeight(.semibold)
            
            if let result = testResult {
                HStack(spacing: 12) {
                    Image(systemName: result.contains("成功") ? "checkmark.circle.fill" : "xmark.circle.fill")
                        .font(.title)
                        .foregroundColor(result.contains("成功") ? .green : .red)
                    Text(result)
                        .font(.body)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(12)
            } else if isTesting {
                HStack(spacing: 12) {
                    ProgressView()
                    Text("正在测试连接...")
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(12)
            } else {
                Button(action: { testConnection() }) {
                    HStack {
                        Image(systemName: "arrow.right.circle")
                            .font(.largeTitle)
                        Text("开始测试")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
            }
            
            Text("当前配置:")
                .font(.caption)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("• 后端: \(currentBackendName)")
                Text("• 模型: \(settings.model)")
                Text("• 服务器: \(serverInfo)")
                if needsKey && !settings.apiKey.isEmpty {
                    Text("• API Key: \(String(settings.apiKey.prefix(4))...\(String(settings.apiKey.suffix(4)))")
                }
            }
            .font(.caption)
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemBackground))
            .cornerRadius(8)
        }
    }
    
    private var needsKey: Bool {
        AppSettings.backends.first(where: { $0.name == settings.backend })?.needsKey ?? true
    }
    
    private var currentBackendName: String {
        AppSettings.backends.first(where: { $0.name == settings.backend })?.displayName ?? "OpenAI"
    }
    
    private var serverInfo: String {
        if settings.serverIP.isEmpty {
            return "云端"
        }
        return "http://\(settings.serverIP):\(settings.port)"
    }
    
    private var keyInfoMessage: String {
        switch settings.backend {
        case "openai":
            return "1. 打开 https://platform.openai.com\n2. 注册账号\n3. 点击 API Keys\n4. 创建新Key\n5. 复制粘贴到这里\n\n注意: OpenAI需要付费，前$5免费"
        case "groq":
            return "1. 打开 https://console.groq.com\n2. 用GitHub注册\n3. 点击 API Keys\n4. 创建新Key\n\nGroq提供免费额度，推荐新用户!"
        case "mistral":
            return "1. 打开 https://console.mistral.ai\n2. 注册账号\n3. 点击 API Keys\n4. 创建新Key\n\nMistral提供免费额度"
        default:
            return "请在 https://console.\(settings.backend).com 获取 API Key"
        }
    }
    
    private func backendIcon(_ name: String) -> String {
        switch name {
        case "openai": return "brain.head.profile"
        case "ollama": return "server.rack"
        case "llamacpp": return "cpu"
        case "lmstudio": return "desktopcomputer"
        case "groq": return "bolt"
        case "mistral": return "wind"
        default: return "gearshape"
        }
    }
    
    private func testConnection() {
        isTesting = true
        testResult = nil
        
        Task {
            do {
                let runner = settings.makeRunner()
                let response = try await runner.chat(
                    messages: [ChatMessage(role: "user", content: "Hello")],
                    stream: false
                )
                
                await MainActor.run {
                    if !response.isEmpty {
                        testResult = "连接成功! 模型已就绪。"
                    } else {
                        testResult = "连接成功但无响应，请检查模型名称。"
                    }
                    isTesting = false
                }
            } catch {
                await MainActor.run {
                    testResult = "连接失败: \(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }
}
