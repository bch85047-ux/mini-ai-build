// TerminalView.swift
// 内置终端 - 引导配置本地服务器

import SwiftUI
import MiniAICore

struct TerminalView: View {
    @EnvironmentObject var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State private var commandOutput: String = ""
    @State private var showIshGuide = false
    @State private var copied = false
    
    let steps: [(title: String, command: String, desc: String)] = [
        (
            title: "1. 启动服务器",
            command: "sh /var/minis/workspace/setup-local-ai.sh",
            desc: "启动 Python 本地服务器 (无需模型)"
        ),
        (
            title: "2. 编译真 AI (可选)",
            command: "sh /var/minis/workspace/build-llama-ish.sh",
            desc: "编译 llama.cpp (30 分钟，只一次)"
        ),
        (
            title: "3. 下载模型 (可选)",
            command: "sh /var/minis/workspace/download-model.sh",
            desc: "下载无审查模型 (1-2GB)"
        ),
        (
            title: "4. 启动真 AI 服务器",
            command: "sh /var/minis/workspace/start-ai.sh",
            desc: "启动 llama.cpp 服务器"
        )
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // 标题
                    VStack(spacing: 8) {
                        Image(systemName: "terminal")
                            .font(.system(size: 48))
                            .foregroundColor(.green)
                        Text("快速配置终端")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("复制命令到 iSH 运行")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 20)
                    
                    // 快速启动按钮
                    Button(action: {
                        UIPasteboard.general.string = "sh /var/minis/workspace/setup-local-ai.sh"
                        withAnimation { copied = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation { copied = false }
                        }
                    }) {
                        HStack {
                            Image(systemName: copied ? "checkmark.circle.fill" : "play.circle.fill")
                                .font(.title2)
                            Text(copied ? "已复制！" : "一键启动服务器")
                                .font(.headline)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(copied ? Color.green : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    
                    // 命令列表
                    ForEach(steps.indices, id: \.self) { i in
                        commandCard(step: steps[i], index: i)
                    }
                    
                    // iSH 指南
                    Button(action: { showIshGuide = true }) {
                        HStack {
                            Image(systemName: "questionmark.circle")
                                .font(.title3)
                            Text("需要安装 iSH?")
                                .font(.headline)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(12)
                    }
                    .buttonStyle(.plain)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationTitle("配置终端")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showIshGuide) {
                IShGuideView()
            }
        }
    }
    
    private func commandCard(step: (title: String, command: String, desc: String), index: Int) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "chevron.right.circle.fill")
                    .font(.title3)
                    .foregroundColor(.green)
                Text(step.title)
                    .font(.headline)
            }
            
            Text(step.desc)
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text(step.command)
                    .font(.system(.caption, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(8)
                    .background(Color(.tertiarySystemBackground))
                    .cornerRadius(6)
                
                Button {
                    UIPasteboard.general.string = step.command
                    withAnimation { copied = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        withAnimation { copied = false }
                    }
                } label: {
                    Image(systemName: copied ? "checkmark" : "doc.on.doc")
                        .font(.caption)
                }
            }
        }
        .padding(16)
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
    }
}

struct IShGuideView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var appStoreURL: URL = URL(string: "https://apps.apple.com/app/ish-linux-shell/id983324009")!
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "terminal")
                    .font(.system(size: 64))
                    .foregroundColor(.green)
                
                Text("安装 iSH")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("在 App Store 搜索 \"iSH\" 下载安装")
                    .font(.title3)
                    .foregroundColor(.secondary)
                
                Link("打开 App Store", destination: appStoreURL)
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    .padding(.top, 20)
                
                Text("安装后：")
                    .font(.headline)
                    .padding(.top, 20)
                
                VStack(alignment: .leading, spacing: 12) {
                    guideStep("1", "打开 iSH")
                    guideStep("2", "等待初始化完成")
                    guideStep("3", "返回本 App")
                    guideStep("4", "复制命令到 iSH 运行")
                }
                
                Spacer()
                
                Button("关闭") { dismiss() }
                    .buttonStyle(.bordered)
            }
            .padding()
            .navigationTitle("iSH 安装指南")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    private func guideStep(_ num: String, _ text: String) -> some View {
        HStack {
            Text(num)
                .font(.headline)
                .frame(width: 24, height: 24)
                .background(Color.blue)
                .foregroundColor(.white)
                .clipShape(Circle())
            Text(text)
                .font(.body)
        }
    }
}
