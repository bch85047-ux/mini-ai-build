import java.io.*;

public class TerminalEngine {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line;
        StringBuilder sb = new StringBuilder();
        
        System.out.println("[Terminal Engine Ready]");
        System.out.flush();
        
        while (true) {
            System.out.print("> ");
            System.out.flush();
            
            try {
                line = br.readLine();
                if (line == null) break;
                
                // Echo command
                System.out.println("$ " + line);
                
                // Handle commands
                String cmd = line.trim();
                
                switch (cmd) {
                    case "status":
                        System.out.println("IP: 192.168.1.100");
                        System.out.println("Port: 11434");
                        System.out.println("Server: Python");
                        break;
                    case "setup":
                        System.out.println("Running setup...");
                        break;
                    case "start":
                        System.out.println("Starting server on port 11434...");
                        break;
                    case "help":
                        System.out.println("Commands: status, setup, start, stop, help");
                        break;
                    case "exit":
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Command: " + cmd);
                        break;
                }
                System.out.println();
                System.out.flush();
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
