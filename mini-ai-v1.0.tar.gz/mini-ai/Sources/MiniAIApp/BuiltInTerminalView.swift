// BuiltInTerminalView.swift
// 内置终端 - 直接在 App 里运行命令

import SwiftUI
import MiniAICore

struct BuiltInTerminalView: View {
    @EnvironmentObject var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @StateObject private var executor = ShellExecutor()
    @State private var input = ""
    @State private var showHelp = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 终端输出区
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 4) {
                            // 欢迎信息
                            terminalLine("╔═══════════════════════════════════════════╗")
                            terminalLine("║  MiniAI 内置终端 v1.0                    ║")
                            terminalLine("║  直接运行，不需要 iSH                     ║")
                            terminalLine("╚═══════════════════════════════════════════╝")
                            terminalLine("")
                            terminalLine("输入 'help' 查看命令")
                            terminalLine("")
                            
                            // 命令历史
                            ForEach(Array(executor.output.enumerated()), id: \.offset) { _, line in
                                terminalLine(line)
                            }
                            
                            // 光标
                            HStack {
                                Text("> ")
                                    .foregroundColor(.green)
                                Text("|")
                                    .foregroundColor(.green)
                                    .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: isProcessing)
                            }
                            .font(.system(.caption, design: .monospaced))
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.black)
                    }
                    .onChange(of: executor.output) { _ in
                        withAnimation {
                            proxy.scrollTo(executor.output.count, anchor: .bottom)
                        }
                    }
                }
                
                Divider()
                
                // 快捷命令栏
                HStack(spacing: 8) {
                    quickButton("help", color: .blue) {
                        input = "help"
                        executor.execute(command: "help")
                    }
                    quickButton("status", color: .green) {
                        input = "status"
                        executor.execute(command: "status")
                    }
                    quickButton("setup", color: .orange) {
                        input = "setup"
                        executor.execute(command: "setup")
                    }
                    quickButton("start", color: .red) {
                        input = "start"
                        executor.execute(command: "start")
                    }
                    quickButton("models", color: .purple) {
                        input = "models"
                        executor.execute(command: "models")
                    }
                }
                .padding(8)
                .background(Color(.secondarySystemBackground))
                
                // 输入框
                HStack(spacing: 8) {
                    Text(">")
                        .foregroundColor(.green)
                        .font(.system(.body, design: .monospaced))
                    
                    TextField("输入命令...", text: $input)
                        .font(.system(.body, design: .monospaced))
                        .autocorrectionDisabled()
                        .autocapitalization(.none)
                        .onSubmit {
                            sendCommand()
                        }
                    
                    Button {
                        sendCommand()
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title2)
                            .foregroundColor(.green)
                    }
                }
                .padding(12)
                .background(Color(.secondarySystemBackground))
            }
            .navigationTitle("内置终端")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        executor.clear()
                    } label: {
                        Image(systemName: "trash")
                    }
                }
            }
        }
    }
    
    @State private var isProcessing = false
    
    private func terminalLine(_ text: String) -> some View {
        Text(text.isEmpty ? " " : text)
            .font(.system(.caption, design: .monospaced))
            .foregroundColor(text.contains("╔") || text.contains("╠") || text.contains("╚") || text.contains("═") ? .green : .white)
    }
    
    private func quickButton(_ title: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .fontWeight(.medium)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(color)
                .foregroundColor(.white)
                .cornerRadius(6)
        }
        .buttonStyle(.plain)
    }
    
    private func sendCommand() {
        let cmd = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cmd.isEmpty else { return }
        
        input = ""
        executor.execute(command: cmd)
    }
}
