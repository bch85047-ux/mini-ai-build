// AppSettings.swift
// Author: 海鸥
// Purpose: 应用设置 - 持久化到UserDefaults

import Foundation
import Combine
import MiniAICore

@MainActor
final class AppSettings: ObservableObject {
    @AppStorage("ai_backend") var backend: String = "ollama"
    @AppStorage("ai_model") var model: String = "qwen2.5:7b-instruct"
    @AppStorage("ai_server_ip") var serverIP: String = "192.168.1.100"
    @AppStorage("ai_port") var port: Int = 11434
    @AppStorage("ai_brave_key") var braveKey: String = ""
    @AppStorage("ai_max_rounds") var maxRounds: Int = 8
    @AppStorage("ai_temperature") var temperature: Double = 0.7
    @AppStorage("ai_system_prompt") var systemPrompt: String = SystemPrompts.base

    static let shared = AppSettings()

    /// 构建当前配置的ModelRunner
    func makeRunner() -> OpenAIRunner {
        let baseUrlString: String
        switch backend {
        case "llamacpp":
            baseUrlString = "http://\(serverIP):\(port)"
        case "lmstudio":
            baseUrlString = "http://\(serverIP):\(port)/v1"
        case "ollama", "custom", _:
            baseUrlString = "http://\(serverIP):\(port)/api"
        }
        let key = (backend == "lmstudio") ? "lm-studio" :
                  (backend == "ollama" ? "ollama" : "")
        return OpenAIRunner(config: .init(
            baseURL: URL(string: baseUrlString)!,
            apiKey: key.isEmpty ? nil : key,
            model: model,
            temperature: temperature,
            contextLength: 8192
        ))
    }
}
