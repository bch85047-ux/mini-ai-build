// BridgeHandler.h
#import <Foundation/Foundation.h>

@interface BridgeHandler : NSObject
+ (void)executeCommand:(NSString *)command;
@end
