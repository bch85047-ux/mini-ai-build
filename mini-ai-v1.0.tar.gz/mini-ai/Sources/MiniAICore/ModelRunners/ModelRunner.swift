// ModelRunner Protocol.swift
// Author: 海鸥
// Purpose: 模型推理抽象层 - 多后端支持

import Foundation

/// 模型推理后端协议
public protocol ModelRunner: AnyObject {
    /// 模型名称/路径
    var modelID: String { get }
    /// 上下文窗口大小
    var contextLength: Int { get }
    /// 是否支持tool calling
    var supportsTools: Bool { get }

    /// 生成消息
    func generate(
        messages: [Message],
        tools: [ToolDefinition]?,
        temperature: Double?,
        maxTokens: Int?,
        topP: Double?
    ) async throws -> ModelOutput
}

/// 推理配置
public struct RunnerConfig {
    public var baseURL: URL
    public var apiKey: String?
    public var model: String
    public var temperature: Double = 0.7
    public var topP: Double = 0.9
    public var maxTokens: Int = 2048
    public var contextLength: Int = 8192
    public var timeout: Int64 = 120

    public init(
        baseURL: URL,
        apiKey: String? = nil,
        model: String,
        temperature: Double = 0.7,
        topP: Double = 0.9,
        maxTokens: Int = 2048,
        contextLength: Int = 8192,
        timeout: Int64 = 120
    ) {
        self.baseURL = baseURL
        self.apiKey = apiKey
        self.model = model
        self.temperature = temperature
        self.topP = topP
        self.maxTokens = maxTokens
        self.contextLength = contextLength
        self.timeout = timeout
    }
}
