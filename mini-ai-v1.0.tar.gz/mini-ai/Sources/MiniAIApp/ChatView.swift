// ChatView.swift
// Author: 海鸥
// Purpose: 聊天主界面

import SwiftUI
import MiniAICore


@MainActor
final class ChatViewModel: ObservableObject {
    struct Bubble: Identifiable {
        let id = UUID()
        let role: String
        let text: String
    }
    struct ToolEvent: Identifiable {
        let id = UUID()
        let name: String
        let resultLength: Int
    }
    
    struct Attachment: Identifiable, Hashable {
        let id = UUID()
        let name: String
        let content: String
        var size: String { "\(content.count) B" }
    }

    @Published var bubbles: [Bubble] = []
    @Published var toolEvents: [ToolEvent] = []
    @Published var input = ""
    @Published var isLoading = false
    @Published var statusText = "就绪"
    @Published var pendingAttachments: [Attachment] = []

    private var engine: ChatEngine?
    private let settings: AppSettings

    init(settings: AppSettings) {
        self.settings = settings
        rebuildEngine()
    }

    func rebuildEngine() {
        let runner = settings.makeRunner()
        let engine = ChatEngine(
            runner: runner,
            maxToolRounds: settings.maxRounds,
            systemPrompt: settings.systemPrompt
        )
        engine.loadStandardTools(braveAPIKey: settings.braveKey.isEmpty ? nil : settings.braveKey)
        self.engine = engine
        self.bubbles = []
        self.toolEvents = []
        self.statusText = "就绪 (\(engine.toolNames.joined(separator: ", ")))"
    }

    func send() async {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isLoading else { return }
        
        // Append attachments to message
        for att in pendingAttachments {
            text += "\n\n[附件: \(att.name)]\n\(att.content)"
        }
        pendingAttachments = []
        input = ""
        bubbles.append(.init(role: "user", text: text))
        toolEvents.removeAll()
        isLoading = true
        
        // Demo mode - no server needed
        if settings.demoMode {
            statusText = "演示模式..."
            defer {
                isLoading = false
                statusText = "就绪"
            }
            await demoReply()
            return
        }
        
        // 检查服务器IP是否为空
        if settings.serverIP.isEmpty {
            isLoading = false
            bubbles.append(.init(role: "assistant", text: """
                ❌ **未配置服务器**
                
                请先启动 Mac 上的 Ollama:
                
                ```
                ollama serve
                ```
                
                然后 App 会自动扫描发现并连接。
                
                ---
                
                💡 如果自动发现失败:
                1. 确保 iPad 和 Mac 在同一 WiFi
                2. 打开设置 → 手动输入 Mac IP
                3. 或开启演示模式(顶部按钮)
                """))
            return
        }
        
        guard let engine else {
            isLoading = false
            bubbles.append(.init(role: "assistant", text: "❌ 请先配置服务器"))
            return
        }
        
        statusText = "思考中..."
        defer {
            isLoading = false
            statusText = "就绪"
        }

        do {
            let reply = try await engine.chat(
                userMessage: text,
                temperature: settings.temperature,
                onToolCall: { _, name in
                    Task { @MainActor in
                        self.toolEvents.append(.init(name: name, resultLength: 0))
                    }
                },
                onResult: { result in
                    Task { @MainActor in
                        if !self.toolEvents.isEmpty {
                            let i = self.toolEvents.count - 1
                            self.toolEvents[i] = .init(
                                name: self.toolEvents[i].name,
                                resultLength: result.count
                            )
                        }
                    }
                }
            )
            bubbles.append(.init(role: "assistant", text: reply))
        } catch {
            let err = error.localizedDescription
            
            // 判断错误类型
            if err.contains("Connection refused") || err.contains("Connection closed") || err.contains("Unable to connect") {
                bubbles.append(.init(role: "assistant", text: """
                    ❌ **无法连接服务器**
                    
                    服务器未响应，可能原因：
                    
                    1. **服务器未启动** - 请确保 Ollama/llama.cpp 已运行
                    2. **IP 或端口错误** - 检查设置中的服务器地址
                    3. **网络不通** - 确保设备和服务器在同一 WiFi
                    4. **防火墙阻止** - 检查服务器防火墙设置
                    
                    ---
                    
                    💡 **快速解决**：
                    • 打开设置 → 测试连接
                    • 或点击顶部"演示模式"按钮
                    • 或扫描局域网自动发现服务器
                    """))
            } else if err.contains("401") || err.contains("Unauthorized") || err.contains("invalid_api_key") {
                bubbles.append(.init(role: "assistant", text: """
                    ❌ **API Key 无效**
                    
                    请检查：
                    1. API Key 是否正确复制
                    2. 是否有空格或多余字符
                    3. Key 是否已过期
                    
                    ---
                    
                    💡 打开设置 → 重新输入 API Key
                    """))
            } else if err.contains("429") || err.contains("rate limit") {
                bubbles.append(.init(role: "assistant", text: """
                    ⏳ **请求过于频繁**
                    
                    您的 API 配额已用完或触发限流。
                    
                    请稍等几分钟后重试，或：
                    • 切换到其他模型
                    • 检查 API 配额设置
                    """))
            } else {
                bubbles.append(.init(role: "assistant", text: """
                    ❌ **错误**
                    
                    错误: \(err)
                    
                    ---
                    
                    💡 打开设置查看详情，或联系开发者
                    """))
            }
        }
    }

    func addAttachment(name: String, content: String) {
        pendingAttachments.append(Attachment(name: name, content: content))
    }
    
    func removeAttachment(_ att: Attachment) {
        pendingAttachments.removeAll { $0.id == att.id }
    }
    
    private func demoReply() async {
        // 模拟AI回复 - 无需网络
        let replies = [
            "你好！我是 MiniAI 演示模式。",
            "这是离线演示，没有连接AI服务器。",
            "要使用真实AI，请在设置中配置后端。",
            "支持: OpenAI, Ollama, Groq, llama.cpp 等。",
            "文件管理功能可以正常使用！"
        ]
        
        let reply = replies.randomElement()!
        
        // 模拟打字效果
        for char in reply {
            try? await Task.sleep(nanoseconds: 50_000_000)
            if let last = bubbles.last, last.role == "assistant" {
                bubbles[bubbles.count - 1].text += String(char)
            } else {
                bubbles.append(.init(role: "assistant", text: String(char)))
            }
        }
        
        isLoading = false
    }
    
    func autoScanAndConnect() async {
        // 扫描局域网
        await scanner.scan()
        
        if let server = scanner.discoveredServers.first {
            // 自动连接发现的服务器
            await MainActor.run {
                settings.serverIP = server.ip
                settings.port = server.port
                settings.backend = server.type == .ollama ? "ollama" : (server.type == .llamaCpp ? "llamacpp" : "lmstudio")
                settings.demoMode = false
                vm.rebuildEngine()
            }
            statusText = "已连接: \(server.ip):\(server.port)"
        } else {
            // 没找到服务器
            statusText = "未找到服务器，请启动 Mac Ollama"
        }
    }
    
    func connectToServer(_ server: NetworkScanner.ServerInfo) {
        settings.serverIP = server.ip
        settings.port = server.port
        settings.backend = server.type == .ollama ? "ollama" : (server.type == .llamaCpp ? "llamacpp" : "lmstudio")
        settings.demoMode = false
        showServerAlert = false
    }
    
    func clearHistory() {
        engine?.reset()
        bubbles.removeAll()
        toolEvents.removeAll()
    }
}

struct ChatView: View {
    @EnvironmentObject var settings: AppSettings
    @StateObject private var vm: ChatViewModel

    init() {
        _vm = StateObject(wrappedValue: ChatViewModel(settings: AppSettings.shared))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            if vm.bubbles.isEmpty {
                                welcomeCard
                            }
                            ForEach(vm.bubbles) { b in
                                BubbleView(bubble: b)
                                    .id(b.id)
                            }
                            if vm.toolEvents.isEmpty == false && vm.isLoading {
                                toolEventsCard
                            }
                            if vm.isLoading && vm.toolEvents.isEmpty {
                                thinkingCard
                            }
                        }
                        .padding()
                    }
                    .onChange(of: vm.bubbles.count) { _, _ in
                        if let last = vm.bubbles.last {
                            withAnimation {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }

                Divider()
                
                // 附件预览
                if !vm.pendingAttachments.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(vm.pendingAttachments) { att in
                                HStack(spacing: 4) {
                                    Image(systemName: "doc")
                                        .foregroundColor(.blue)
                                    Text(att.name)
                                        .font(.caption)
                                        .lineLimit(1)
                                        .frame(maxWidth: 100)
                                    Button(action: { vm.removeAttachment(att) }) {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.red.opacity(0.6))
                                    }
                                }
                                .padding(6)
                                .background(Color.blue.opacity(0.1))
                                .cornerRadius(8)
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                    }
                }
                
                Divider()
                inputBar
            }
            .navigationTitle("MiniAI")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        vm.clearHistory()
                    } label: {
                        Image(systemName: "trash")
                    }
                    .disabled(vm.bubbles.isEmpty)
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        vm.rebuildEngine()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                statusFooter
            }
            .sheet(isPresented: $showAttachmentPicker) {
                AttachmentPickerSheet(
                    onPick: { name, content in
                        vm.addAttachment(name: name, content: content)
                    }
                )
            }
        }
    }

    private var welcomeCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("你好，我是MiniAI").font(.title2.bold())
            Text("本地运行，无审查，支持联网搜索与文件读写。")
                .foregroundStyle(.secondary)
            Text("试试: \"今天新闻有什么\" / \"帮我写个python脚本\"")
                .font(.caption).foregroundStyle(.tertiary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemGray6)))
    }

    private var thinkingCard: some View {
        HStack {
            ProgressView()
            Text(vm.statusText).foregroundStyle(.secondary)
            Spacer()
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemGray6)))
    }

    private var toolEventsCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(vm.toolEvents) { ev in
                HStack(spacing: 8) {
                    Image(systemName: "wrench.and.screwdriver")
                    Text(ev.name).font(.system(.caption, design: .monospaced))
                    Spacer()
                    Text(ev.resultLength > 0 ? "\(ev.resultLength) chars" : "调用中...")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(.systemGray6)))
    }

    private var inputBar: some View {
        HStack(spacing: 8) {
            // 附件按钮
            Button(action: { showAttachmentSheet() }) {
                Image(systemName: "paperclip")
                    .font(.system(size: 20))
                    .foregroundColor(.secondary)
            }
            
            TextField("输入消息...", text: $vm.input, axis: .vertical)
                .lineLimit(1...5)
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 20).fill(Color(.systemGray6)))
                .onSubmit { Task { await vm.send() } }
            Button {
                Task { await vm.send() }
            } label: {
                Image(systemName: vm.isLoading ? "ellipsis" : "arrow.up.circle.fill")
                    .font(.system(size: 30))
            }
            .disabled(vm.isLoading || vm.input.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .padding()
        .background(Color(.systemBackground))
    }

    @State private var showAttachmentPicker = false
    
    private func showAttachmentSheet() {
        showAttachmentPicker = true
    }
    
    private var statusFooter: some View {
        HStack {
            Circle()
                .fill(vm.isLoading ? Color.orange : Color.green)
                .frame(width: 8, height: 8)
            Text(vm.statusText)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Spacer()
            Text("\(settings.backend) / \(settings.model)")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 4)
        .background(Color(.systemBackground).opacity(0.9))
    }
}

struct BubbleView: View {
    let bubble: ChatViewModel.Bubble

    var body: some View {
        HStack {
            if bubble.role == "user" { Spacer() }
            MessageBubbleView(bubble: bubble)
            if bubble.role != "user" { Spacer() }
        }
    }
}

struct MessageBubbleView: View {
    let bubble: ChatViewModel.Bubble
    @State private var textAttr: AttributedString = AttributedString()

    var body: some View {
        Text(textAttr)
            .padding(12)
            .frame(maxWidth: 480, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 14).fill(
                bubble.role == "user" ? Color.blue : Color(.systemGray6)
            ))
            .foregroundStyle(bubble.role == "user" ? .white : .primary)
            .onAppear {
                textAttr = parseMarkdown(bubble.text)
            }
            .contextMenu {
                Button {
                    UIPasteboard.general.string = bubble.text
                } label: {
                    Label("复制", systemImage: "doc.on.doc")
                }
            }
    }

    private func parseMarkdown(_ s: String) -> AttributedString {
        var attr = AttributedString(s)
        // 简单代码块标记
        if s.contains("```") {
            let parts = s.components(separatedBy: "```")
            var newAttr = AttributedString()
            for (i, part) in parts.enumerated() {
                if i.isMultiple(of: 2) {
                    newAttr += AttributedString(part)
                } else {
                    var code = AttributedString(part)
                    code.font = .system(.body, design: .monospaced)
                    code.foregroundColor = .primary
                    newAttr += code
                }
            }
            return newAttr
        }
        return attr
    }
}


// MARK: - 附件选择器

struct AttachmentPickerSheet: View {
    let onPick: (String, String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var textContent = ""
    @State private var fileName = "note.txt"
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("新建文本文件")) {
                    TextField("文件名", text: $fileName)
                    TextField("内容", text: $textContent, axis: .vertical)
                        .lineLimit(5...10)
                }
                
                Section(header: Text("或从本地文件选择")) {
                    Button(action: { pickFromFile() }) {
                        Label("从文件选择...", systemImage: "folder")
                    }
                }
            }
            .navigationTitle("附加文件")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("附加") {
                        let name = fileName.isEmpty ? "note.txt" : fileName
                        onPick(name, textContent.isEmpty ? "empty" : textContent)
                        dismiss()
                    }
                    .disabled(textContent.isEmpty && fileName == "note.txt")
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }
    
    private func pickFromFile() {
        // 简化版：实际应使用 PHPickerViewController
        // 这里暂用示例内容
        onPick("from_files.txt", "File selected from picker")
        dismiss()
    }
}
