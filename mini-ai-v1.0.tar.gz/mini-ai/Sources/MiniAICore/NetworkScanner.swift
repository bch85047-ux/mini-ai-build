// NetworkScanner.swift
// Purpose: 局域网扫描 - 自动检测本地AI服务器

import Foundation
#if canImport(Network)
import Network
#endif

@MainActor
final class NetworkScanner: ObservableObject {
    @Published var discoveredServers: [ServerInfo] = []
    @Published var isScanning = false
    @Published var scanStatus = ""
    
    struct ServerInfo: Identifiable, Hashable {
        let id = UUID()
        let ip: String
        let port: Int
        let type: ServerType
        let status: String
    }
    
    enum ServerType: String {
        case ollama = "Ollama"
        case llamaCpp = "llama.cpp"
        case lmStudio = "LM Studio"
        case openAI = "OpenAI"
        case unknown = "Unknown"
    }
    
    /// 扫描局域网寻找AI服务器
    func scan() async {
        isScanning = true
        scanStatus = "正在扫描局域网..."
        discoveredServers = []
        
        let commonIPs = generateCommonIPs()
        
        for ip in commonIPs {
            if await checkServer(ip: ip, port: 11434) {
                let info = ServerInfo(ip: ip, port: 11434, type: .ollama, status: "Ollama 运行中")
                await MainActor.run { discoveredServers.append(info) }
                scanStatus = "发现: \(ip):11434"
            }
            
            if await checkServer(ip: ip, port: 8080) {
                let info = ServerInfo(ip: ip, port: 8080, type: .llamaCpp, status: "llama.cpp 运行中")
                await MainActor.run { discoveredServers.append(info) }
                scanStatus = "发现: \(ip):8080"
            }
            
            if await checkServer(ip: ip, port: 1234) {
                let info = ServerInfo(ip: ip, port: 1234, type: .lmStudio, status: "LM Studio 运行中")
                await MainActor.run { discoveredServers.append(info) }
                scanStatus = "发现: \(ip):1234"
            }
        }
        
        await MainActor.run {
            isScanning = false
            if discoveredServers.isEmpty {
                scanStatus = "未找到服务器"
            } else {
                scanStatus = "扫描完成，发现 \(discoveredServers.count) 个服务器"
            }
        }
    }
    
    private func generateCommonIPs() -> [String] {
        var ips = [
            "192.168.1.1", "192.168.1.100", "192.168.1.200",
            "192.168.0.1", "192.168.0.100",
            "10.0.0.1", "10.0.0.100",
            "10.10.10.1", "10.10.10.100"
        ]
        
        // 尝试获取本机IP
        if let localIP = getLocalIP() {
            ips.insert(localIP, at: 0)
        }
        
        // 生成更多IP
        if let localIP = getLocalIP() {
            let parts = localIP.split(separator: ".")
            if parts.count == 4 {
                let base = parts.prefix(3).joined(separator: ".")
                for i in 1..<255 {
                    let ip = "\(base).\(i)"
                    if !ips.contains(ip) {
                        ips.append(ip)
                    }
                }
            }
        }
        
        return ips
    }
    
    private func getLocalIP() -> String? {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        
        if getifaddrs(&ifaddr) == 0 {
            defer { freeifaddrs(ifaddr) }
            
            var ptr = ifaddr
            while ptr != nil {
                let addr = ptr!.ifa_addr.pointee
                if addr.sa_family == UInt8(AF_INET) {
                    let name = String(cString: ptr!.ifa_name)
                    if name == "en0" || name == "en1" {
                        var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if getnameinfo(addr, socklen_t(addr.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                            address = String(cString: host)
                        }
                    }
                }
                ptr = ptr!.ifa_next
            }
        }
        
        return address
    }
    
    private func checkServer(ip: String, port: Int) async -> Bool {
        return await withCheckedContinuation { continuation in
            let task = Task {
                defer { continuation.resume(returning: false) }
                
                let url = URL(string: "http://\(ip):\(port)")!
                let semaphore = DispatchSemaphore(value: 0)
                var result = false
                
                var request = URLRequest(url: url)
                request.timeoutInterval = 1.0
                
                let task = URLSession.shared.dataTask(with: request) { _, response, _ in
                    if let http = response as? HTTPURLResponse, http.statusCode == 200 {
                        result = true
                    }
                    semaphore.signal()
                }
                task.resume()
                
                semaphore.wait(timeout: .now() + 1.5)
                
                if result {
                    continuation.resume(returning: true)
                }
            }
            
            // Give it a moment
            Task {
                try? await Task.sleep(nanoseconds: 100_000_000)
            }
        }
    }
}
