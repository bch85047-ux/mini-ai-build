// swift-tools-version: 5.9
// Package: mini-ai
// Target: iOS 17.0+ / iPadOS 17.0+ / macOS 14.0+
// Description: 本地AI助手核心库 + CLI

import PackageDescription

let package = Package(
    name: "MiniAI",
    platforms: [
        .iOS(.v17),
        .iPadOS(.v17),
        .macOS(.v14)
    ],
    products: [
        .library(name: "MiniAICore", targets: ["MiniAICore"]),
        .executable(name: "mini-ai-cli", targets: ["mini-ai-cli"])
    ],
    dependencies: [
        // MLX Swift for native Apple Silicon inference
        // Uncomment when ready for local MLX inference
        // .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.13.0"),
        // .package(url: "https://github.com/ml-explore/mlx-swift-examples.git", branch: "main")
    ],
    targets: [
        .target(
            name: "MiniAICore",
            dependencies: [
                // .product(name: "MLXSwift", package: "mlx-swift"),
                // .product(name: "MLXNN", package: "mlx-swift"),
                // .product(name: "MLXLM", package: "mlx-swift-examples")
            ],
            path: "Sources/MiniAICore"
        ),
        .executableTarget(
            name: "mini-ai-cli",
            dependencies: ["MiniAICore"],
            path: "Sources/mini-ai-cli"
        ),
        // MiniAIApp 源码在 Sources/MiniAIApp/ 但作为library target，
        // 实际部署时复制到Xcode App项目中，不通过SPM打包
        .testTarget(
            name: "MiniAITests",
            dependencies: ["MiniAICore"],
            path: "Tests/MiniAITests"
        )
    ]
)
