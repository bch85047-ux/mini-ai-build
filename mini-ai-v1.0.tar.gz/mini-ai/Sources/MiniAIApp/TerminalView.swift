// TerminalView.swift
// 内置终端 - 快速配置本地服务器

import SwiftUI
import MiniAICore

struct TerminalView: View {
    @EnvironmentObject var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State private var commandHistory: [String] = []
    @State private var currentCommand = ""
    @State private var output = ""
    @State private var showIshGuide = false
    @State private var copied = false
    @State private var selectedModel: ModelInfo? = nil
    
    struct ModelInfo: Identifiable {
        let id = UUID()
        let name: String
        let size: String
        let desc: String
        let url: String
    }
    
    let models: [ModelInfo] = [
        ModelInfo(name: "Qwen2.5-1.8B", size: "1.1GB", desc: "中文优秀", url: "https://huggingface.co/QuantFactory/Qwen2.5-1.8B-Instruct-GGUF/resolve/main/qwen2.5-1.8b-instruct-q4_K_M.gguf"),
        ModelInfo(name: "TinyLlama-1.1B", size: "650MB", desc: "最小最快", url: "https://huggingface.co/QuantFactory/tinyllama-1.1b-chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0-q4_0.gguf"),
        ModelInfo(name: "Phi-2-1.3B", size: "800MB", desc: "英文优秀", url: "https://huggingface.co/QuantFactory/phi-2-GGUF/resolve/main/phi-2-q4_K_M.gguf"),
        ModelInfo(name: "Gemma-2B", size: "1.2GB", desc: "Google出品", url: "https://huggingface.co/QuantFactory/gemma-2b-it-GGUF/resolve/main/gemma-2b-it-q4_K_M.gguf")
    ]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 终端输出区
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        // 欢迎信息
                        terminalLine(text: "MiniAI 本地服务器配置终端", color: .green)
                        terminalLine(text: "================================", color: .gray)
                        terminalLine(text: "", color: .gray)
                        
                        // 状态信息
                        HStack {
                            Text("IP 地址:")
                                .foregroundColor(.cyan)
                            Text("192.168.x.x (请手动查看)")
                                .font(.body)
                        }
                        .padding(.vertical, 2)
                        
                        terminalLine(text: "", color: .gray)
                        terminalLine(text: "可用命令:", color: .yellow)
                        terminalLine(text: "  setup       - 启动 Python 服务器", color: .white)
                        terminalLine(text: "  build       - 编译 llama.cpp", color: .white)
                        terminalLine(text: "  download    - 下载模型", color: .white)
                        terminalLine(text: "  start       - 启动真 AI 服务器", color: .white)
                        terminalLine(text: "  models      - 查看可用模型", color: .white)
                        terminalLine(text: "  help        - 帮助", color: .white)
                        terminalLine(text: "", color: .gray)
                        
                        // 命令历史
                        ForEach(commandHistory, id: \.self) { cmd in
                            HStack {
                                Text("$ ")
                                    .foregroundColor(.green)
                                Text(cmd)
                            }
                            .font(.system(.caption, design: .monospaced))
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.black)
                }
                
                Divider()
                
                // 快捷命令按钮
                HStack(spacing: 8) {
                    quickButton("启动服务器", color: .green) {
                        copyCommand("sh /var/minis/workspace/setup-local-ai.sh")
                    }
                    quickButton("编译", color: .blue) {
                        copyCommand("sh /var/minis/workspace/build-llama-ish.sh")
                    }
                    quickButton("下载模型", color: .orange) {
                        showModelSheet = true
                    }
                    quickButton("启动 AI", color: .purple) {
                        copyCommand("sh /var/minis/workspace/start-ai.sh")
                    }
                }
                .padding(12)
                .background(Color(.secondarySystemBackground))
                
                // 输入框
                HStack(spacing: 8) {
                    TextField("输入命令...", text: $currentCommand)
                        .font(.system(.body, design: .monospaced))
                        .textFieldStyle(.roundedBorder)
                        .autocorrectionDisabled()
                        .onSubmit {
                            executeCommand()
                        }
                    
                    Button {
                        executeCommand()
                    } label: {
                        Image(systemName: "play.circle.fill")
                            .font(.title2)
                            .foregroundColor(.green)
                    }
                }
                .padding(12)
                .background(Color(.secondarySystemBackground))
            }
            .navigationTitle("配置终端")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        UIPasteboard.general.string = "sh /var/minis/workspace/setup-local-ai.sh"
                        alertMessage = "已复制到剪贴板！打开 iSH 粘贴运行"
                    } label: {
                        Image(systemName: "arrow.up.circle")
                    }
                }
            }
            .sheet(isPresented: $showModelSheet) {
                modelSheet
            }
            .alert("提示", isPresented: $showAlert) {
                Button("好的") {}
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    @State private var showModelSheet = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    private func terminalLine(text: String, color: Color) -> some View {
        Text(text.isEmpty ? " " : text)
            .font(.system(.caption, design: .monospaced))
            .foregroundColor(color)
    }
    
    private func quickButton(_ title: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(color)
                .foregroundColor(.white)
                .cornerRadius(6)
        }
        .buttonStyle(.plain)
    }
    
    private func copyCommand(_ cmd: String) {
        UIPasteboard.general.string = cmd
        commandHistory.append(cmd)
        alertMessage = "已复制: \(cmd)"
        showAlert = true
    }
    
    private func executeCommand() {
        let cmd = currentCommand.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cmd.isEmpty else { return }
        
        commandHistory.append(cmd)
        currentCommand = ""
        
        // 简单命令处理
        switch cmd.lowercased() {
        case "help":
            alertMessage = "命令:\nsetup - 启动服务器\nbuild - 编译 llama.cpp\ndownload - 下载模型\nstart - 启动 AI 服务器\nmodels - 查看模型"
        case "models":
            showModelSheet = true
        case "setup":
            copyCommand("sh /var/minis/workspace/setup-local-ai.sh")
        case "build":
            copyCommand("sh /var/minis/workspace/build-llama-ish.sh")
        case "download":
            showModelSheet = true
        case "start":
            copyCommand("sh /var/minis/workspace/start-ai.sh")
        default:
            alertMessage = "命令: \(cmd)\n已复制到剪贴板"
            UIPasteboard.general.string = cmd
        }
        showAlert = true
    }
    
    private var modelSheet: some View {
        NavigationStack {
            List {
                ForEach(models) { model in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(model.name)
                                .font(.headline)
                            Text("\(model.size) - \(model.desc)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Button {
                            copyCommand("wget -O /var/minis/workspace/models/\(model.name.lowercased()).gguf '\(model.url)'")
                        } label: {
                            Label("下载", systemImage: "arrow.down.circle")
                                .font(.caption)
                        }
                    }
                }
            }
            .navigationTitle("模型下载")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showModelSheet = false
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                }
            }
        }
    }
}
