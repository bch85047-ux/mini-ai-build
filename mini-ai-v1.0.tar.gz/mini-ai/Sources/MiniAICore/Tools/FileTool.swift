// FileTool.swift
// Author: 海鸥
// Purpose: 文件读写 + 24小时过期清理

import Foundation

public final class FileTool: Tool {
    public let name = "file_ops"
    public let description = "Read, write, list, and delete files in the workspace."
    public let parameters: [String: ToolParameter]

    private let workspace: URL
    private let tempDir: URL
    private let expirySeconds: Int64 = 86400

    public init(workspace: URL? = nil) {
        self.parameters = [
            "action": ToolParameter(
                type: .string,
                description: "One of: read, write, list, delete, info",
                `enum`: ["read", "write", "list", "delete", "info"]
            ),
            "path": ToolParameter(
                type: .string,
                description: "Relative path within workspace (no .. or absolute paths)."
            ),
            "content": ToolParameter(
                type: .string,
                description: "Content to write (only for action=write).",
                required: false
            )
        ]
        let defaultWS = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("MiniAIWorkspace", isDirectory: true)
        let ws = workspace ?? defaultWS
        self.workspace = ws
        self.tempDir = ws.appendingPathComponent("temp", isDirectory: true)
        ensureDirs()
        cleanupExpired()
    }

    public var workspacePath: String { workspace.path }

    private func ensureDirs() {
        try? FileManager.default.createDirectory(at: workspace, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)
    }

    public func cleanupExpired() {
        let fm = FileManager.default
        let cutoff = Date().addingTimeInterval(-Double(expirySeconds))
        let keys = [URLResourceKey.contentModificationDateKey, URLResourceKey.fileSizeKey]
        guard let items = try? fm.contentsOfDirectory(
            at: tempDir,
            includingPropertiesForKeys: keys
        ) else { return }

        for url in items {
            guard let mtime = try? url.resourceValues(
                forKeys: [URLResourceKey.contentModificationDateKey]
            ).contentModificationDate else { continue }
            if mtime < cutoff {
                try? fm.removeItem(at: url)
            }
        }
    }

    public func execute(_ args: [String: Any]) async throws -> String {
        guard let action = args["action"] as? String else {
            return "Error: 'action' is required"
        }
        let path = args["path"] as? String ?? ""

        guard isSafePath(path) else {
            return "Error: unsafe path (no .. or absolute paths allowed)"
        }

        switch action {
        case "write":
            return try write(path: path, content: args["content"] as? String)
        case "read":
            return try read(path: path)
        case "list":
            return list(path: path)
        case "delete":
            return try delete(path: path)
        case "info":
            return info(path: path)
        default:
            return "Error: unknown action '\(action)'"
        }
    }

    private func isSafePath(_ path: String) -> Bool {
        if path.hasPrefix("/") { return false }
        if path.contains("..") { return false }
        let normalized = workspace.appendingPathComponent(path).standardized.path
        let wsStd = workspace.standardized.path
        return normalized.hasPrefix(wsStd)
    }

    private func write(path: String, content: String?) throws -> String {
        guard let content else {
            return "Error: 'content' required for write action"
        }
        let url = workspace.appendingPathComponent(path)
        try? FileManager.default.createDirectory(
            at: url.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        try content.write(to: url, atomically: true, encoding: .utf8)
        let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int) ?? 0
        return "Written \(content.count) chars (\(size) bytes) to \(path)"
    }

    private func read(path: String) throws -> String {
        let url = workspace.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else {
            return "Error: file not found: \(path)"
        }
        let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int) ?? 0
        if size > 500_000 {
            return "Error: file too large (\(size) bytes)"
        }
        let content = try String(contentsOf: url, encoding: .utf8)
        return content
    }

    private func list(path: String) -> String {
        let dir = path.isEmpty ? workspace : workspace.appendingPathComponent(path)
        let keys = [URLResourceKey.fileSizeKey, URLResourceKey.contentModificationDateKey, URLResourceKey.isDirectoryKey]
        guard let items = try? FileManager.default.contentsOfDirectory(
            at: dir,
            includingPropertiesForKeys: keys
        ) else {
            return "Error: cannot list: \(path)"
        }
        if items.isEmpty {
            return "(empty directory: \(path))"
        }
        var lines = ["Workspace: \(workspace.path)", "Directory: \(path)", ""]
        for url in items.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            let name = url.lastPathComponent
            let props = try? url.resourceValues(
                forKeys: keys
            )
            let isDir = props?.isDirectory ?? false
            let size = props?.fileSize ?? 0
            let mtime = props?.contentModificationDate ?? Date.distantPast
            let mtimeStr = ISO8601DateFormatter().string(from: mtime)
            lines.append(isDir ? "D/ \(name)/" : "F/ \(name)  (\(size)B, \(mtimeStr))")
        }
        return lines.joined(separator: "\n")
    }

    private func delete(path: String) throws -> String {
        let url = workspace.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else {
            return "Error: file not found: \(path)"
        }
        try FileManager.default.removeItem(at: url)
        return "Deleted: \(path)"
    }

    private func info(path: String) -> String {
        let url = workspace.appendingPathComponent(path)
        guard let props = try? FileManager.default.attributesOfItem(atPath: url.path) else {
            return "Error: file not found: \(path)"
        }
        let size = props[.size] as? Int ?? 0
        let mtime = props[.modificationDate] as? Date ?? Date.distantPast
        let mtimeStr = ISO8601DateFormatter().string(from: mtime)
        return "Path: \(path)\nSize: \(size) bytes\nModified: \(mtimeStr)"
    }
}
