// MiniAIApp.swift
// Author: 海鸥
// Purpose: iPad App入口

import SwiftUI

@main
struct MiniAIApp: App {
    @StateObject private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(settings)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var settings: AppSettings
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            ChatView()
                .tabItem { Label("聊天", systemImage: "bubble.left.and.bubble.right") }
                .tag(0)
            WorkspaceView()
                .tabItem { Label("文件", systemImage: "folder") }
                .tag(1)
            SettingsView()
                .tabItem { Label("设置", systemImage: "gear") }
                .tag(2)
        }
    }
}
