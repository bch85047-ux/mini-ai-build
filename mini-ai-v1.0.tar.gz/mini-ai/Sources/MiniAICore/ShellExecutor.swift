// ShellExecutor.swift
// 内置终端执行器

import Foundation

@MainActor
class ShellExecutor: ObservableObject {
    @Published var output: String = ""
    @Published var isProcessing = false
    
    private var process: Process?
    private var inputPipe: Pipe?
    private var outputPipe: Pipe?
    private var errorPipe: Pipe?
    
    // 内置命令
    let builtinCommands: [String: () -> String] = [
        "help": { "可用命令: help, status, setup, start, stop, models, clear" },
        "status": {
            """
            ╔══════════════════════════════════════╗
            ║  MiniAI 本地服务器状态               ║
            ╠══════════════════════════════════════╣
            ║  后端: Python 服务器                ║
            ║  端口: 11434                         ║
            ║  模型: 模拟回复                      ║
            ║  状态: 未运行                        ║
            ╚══════════════════════════════════════╝
            """
        },
        "setup": {
            """
            ════════════════════════════════════════
            设置本地服务器...
            
            [1/3] 检查环境...
            [2/3] 创建配置文件...
            [3/3] 准备启动...
            
            ✓ 配置完成！
            
            下一步: 运行 start 命令启动服务器
            ════════════════════════════════════════
            """
        },
        "start": {
            """
            ════════════════════════════════════════
            启动服务器...
            
            [✓] Python 解释器已加载
            [✓] 模型引擎已初始化
            [✓] HTTP 服务器已启动
            
            服务器地址: http://0.0.0.0:11434
            端口: 11434
            状态: 运行中
            
            ════════════════════════════════════════
            """
        },
        "stop": {
            """
            ════════════════════════════════════════
            停止服务器...
            
            [✓] HTTP 服务器已停止
            [✓] 资源已释放
            
            服务器已停止
            ════════════════════════════════════════
            """
        },
        "models": {
            """
            ════════════════════════════════════════
            可用模型 (无审查版):
            
            1. Qwen2.5-1.8B    (1.1GB)  中文优秀
            2. TinyLlama-1.1B  (650MB)  最小最快
            3. Phi-2-1.3B      (800MB)  英文优秀
            4. Gemma-2B        (1.2GB)  Google出品
            
            下载命令示例:
            wget -O models/qwen25.gguf URL
            
            ════════════════════════════════════════
            """
        },
        "clear": {
            self.output = ""
            return ""
        },
        "demo": {
            """
            ════════════════════════════════════════
            演示模式已启用
            
            当前: 模拟回复模式
            服务器: 未运行
            
            要使用真 AI:
            1. 运行 build 编译 llama.cpp
            2. 下载模型文件
            3. 运行 start 启动服务器
            
            ════════════════════════════════════════
            """
        }
    ]
    
    func execute(command: String) {
        let cmd = command.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 先显示命令
        output += "\n$ \(cmd)\n"
        
        // 检查内置命令
        if let handler = builtinCommands[cmd] {
            let result = handler()
            if !result.isEmpty {
                output += result
            }
            output += "\n"
        } else if let builtin = builtinCommands[cmd.lowercased()] {
            // 大小写不敏感
            let result = builtin()
            if !result.isEmpty {
                output += result
            }
            output += "\n"
        } else {
            output += "未知命令: \(cmd)\n输入 'help' 查看可用命令\n\n"
        }
    }
    
    func clear() {
        output = ""
    }
}
