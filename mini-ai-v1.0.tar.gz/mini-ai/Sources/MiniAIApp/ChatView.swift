// ChatView.swift
// Author: 海鸥
// Purpose: 聊天主界面

import SwiftUI
import MiniAICore


@MainActor
final class ChatViewModel: ObservableObject {
    struct Bubble: Identifiable {
        let id = UUID()
        let role: String
        let text: String
    }
    struct ToolEvent: Identifiable {
        let id = UUID()
        let name: String
        let resultLength: Int
    }
    
    struct Attachment: Identifiable, Hashable {
        let id = UUID()
        let name: String
        let content: String
        var size: String { "\(content.count) B" }
    }

    @Published var bubbles: [Bubble] = []
    @Published var toolEvents: [ToolEvent] = []
    @Published var input = ""
    @Published var isLoading = false
    @Published var statusText = "就绪"
    @Published var pendingAttachments: [Attachment] = []

    private var engine: ChatEngine?
    private let settings: AppSettings

    init(settings: AppSettings) {
        self.settings = settings
        rebuildEngine()
    }

    func rebuildEngine() {
        let runner = settings.makeRunner()
        let engine = ChatEngine(
            runner: runner,
            maxToolRounds: settings.maxRounds,
            systemPrompt: settings.systemPrompt
        )
        engine.loadStandardTools(braveAPIKey: settings.braveKey.isEmpty ? nil : settings.braveKey)
        self.engine = engine
        self.bubbles = []
        self.toolEvents = []
        self.statusText = "就绪 (\(engine.toolNames.joined(separator: ", ")))"
    }

    func send() async {
        var text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isLoading, let engine else { return }
        
        // Append attachments to message
        for att in pendingAttachments {
            text += "\n\n[附件: \(att.name)]\n\(att.content)"
        }
        pendingAttachments = []
        input = ""
        bubbles.append(.init(role: "user", text: text))
        toolEvents.removeAll()
        isLoading = true
        statusText = "思考中..."
        defer {
            isLoading = false
            statusText = "就绪"
        }

        do {
            let reply = try await engine.chat(
                userMessage: text,
                temperature: settings.temperature,
                onToolCall: { _, name in
                    Task { @MainActor in
                        self.toolEvents.append(.init(name: name, resultLength: 0))
                    }
                },
                onResult: { result in
                    Task { @MainActor in
                        if !self.toolEvents.isEmpty {
                            let i = self.toolEvents.count - 1
                            self.toolEvents[i] = .init(
                                name: self.toolEvents[i].name,
                                resultLength: result.count
                            )
                        }
                    }
                }
            )
            bubbles.append(.init(role: "assistant", text: reply))
        } catch {
            let errMsg = "❌ 连接错误\n\n服务器: \(settings.backend)://\(settings.serverIP):\(settings.serverPort)\n错误: \(error.localizedDescription)\n\n请检查:\n1. 服务器是否启动\n2. IP和端口是否正确\n3. 设备是否在同一网络"
            bubbles.append(.init(role: "assistant", text: errMsg))
        }
    }

    func addAttachment(name: String, content: String) {
        pendingAttachments.append(Attachment(name: name, content: content))
    }
    
    func removeAttachment(_ att: Attachment) {
        pendingAttachments.removeAll { $0.id == att.id }
    }
    
    func clearHistory() {
        engine?.reset()
        bubbles.removeAll()
        toolEvents.removeAll()
    }
}

struct ChatView: View {
    @EnvironmentObject var settings: AppSettings
    @StateObject private var vm: ChatViewModel

    init() {
        _vm = StateObject(wrappedValue: ChatViewModel(settings: AppSettings.shared))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            if vm.bubbles.isEmpty {
                                welcomeCard
                            }
                            ForEach(vm.bubbles) { b in
                                BubbleView(bubble: b)
                                    .id(b.id)
                            }
                            if vm.toolEvents.isEmpty == false && vm.isLoading {
                                toolEventsCard
                            }
                            if vm.isLoading && vm.toolEvents.isEmpty {
                                thinkingCard
                            }
                        }
                        .padding()
                    }
                    .onChange(of: vm.bubbles.count) { _, _ in
                        if let last = vm.bubbles.last {
                            withAnimation {
                                proxy.scrollTo(last.id, anchor: .bottom)
                            }
                        }
                    }
                }

                Divider()
                
                // 附件预览
                if !vm.pendingAttachments.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(vm.pendingAttachments) { att in
                                HStack(spacing: 4) {
                                    Image(systemName: "doc")
                                        .foregroundColor(.blue)
                                    Text(att.name)
                                        .font(.caption)
                                        .lineLimit(1)
                                        .frame(maxWidth: 100)
                                    Button(action: { vm.removeAttachment(att) }) {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.red.opacity(0.6))
                                    }
                                }
                                .padding(6)
                                .background(Color.blue.opacity(0.1))
                                .cornerRadius(8)
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                    }
                }
                
                Divider()
                inputBar
            }
            .navigationTitle("MiniAI")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        vm.clearHistory()
                    } label: {
                        Image(systemName: "trash")
                    }
                    .disabled(vm.bubbles.isEmpty)
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        vm.rebuildEngine()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                statusFooter
            }
            .sheet(isPresented: $showAttachmentPicker) {
                AttachmentPickerSheet(
                    onPick: { name, content in
                        vm.addAttachment(name: name, content: content)
                    }
                )
            }
        }
    }

    private var welcomeCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("你好，我是MiniAI").font(.title2.bold())
            Text("本地运行，无审查，支持联网搜索与文件读写。")
                .foregroundStyle(.secondary)
            Text("试试: \"今天新闻有什么\" / \"帮我写个python脚本\"")
                .font(.caption).foregroundStyle(.tertiary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemGray6)))
    }

    private var thinkingCard: some View {
        HStack {
            ProgressView()
            Text(vm.statusText).foregroundStyle(.secondary)
            Spacer()
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemGray6)))
    }

    private var toolEventsCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(vm.toolEvents) { ev in
                HStack(spacing: 8) {
                    Image(systemName: "wrench.and.screwdriver")
                    Text(ev.name).font(.system(.caption, design: .monospaced))
                    Spacer()
                    Text(ev.resultLength > 0 ? "\(ev.resultLength) chars" : "调用中...")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(.systemGray6)))
    }

    private var inputBar: some View {
        HStack(spacing: 8) {
            // 附件按钮
            Button(action: { showAttachmentSheet() }) {
                Image(systemName: "paperclip")
                    .font(.system(size: 20))
                    .foregroundColor(.secondary)
            }
            
            TextField("输入消息...", text: $vm.input, axis: .vertical)
                .lineLimit(1...5)
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 20).fill(Color(.systemGray6)))
                .onSubmit { Task { await vm.send() } }
            Button {
                Task { await vm.send() }
            } label: {
                Image(systemName: vm.isLoading ? "ellipsis" : "arrow.up.circle.fill")
                    .font(.system(size: 30))
            }
            .disabled(vm.isLoading || vm.input.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .padding()
        .background(Color(.systemBackground))
    }

    @State private var showAttachmentPicker = false
    
    private func showAttachmentSheet() {
        showAttachmentPicker = true
    }
    
    private var statusFooter: some View {
        HStack {
            Circle()
                .fill(vm.isLoading ? Color.orange : Color.green)
                .frame(width: 8, height: 8)
            Text(vm.statusText)
                .font(.caption2)
                .foregroundStyle(.secondary)
            Spacer()
            Text("\(settings.backend) / \(settings.model)")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 4)
        .background(Color(.systemBackground).opacity(0.9))
    }
}

struct BubbleView: View {
    let bubble: ChatViewModel.Bubble

    var body: some View {
        HStack {
            if bubble.role == "user" { Spacer() }
            MessageBubbleView(bubble: bubble)
            if bubble.role != "user" { Spacer() }
        }
    }
}

struct MessageBubbleView: View {
    let bubble: ChatViewModel.Bubble
    @State private var textAttr: AttributedString = AttributedString()

    var body: some View {
        Text(textAttr)
            .padding(12)
            .frame(maxWidth: 480, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 14).fill(
                bubble.role == "user" ? Color.blue : Color(.systemGray6)
            ))
            .foregroundStyle(bubble.role == "user" ? .white : .primary)
            .onAppear {
                textAttr = parseMarkdown(bubble.text)
            }
            .contextMenu {
                Button {
                    UIPasteboard.general.string = bubble.text
                } label: {
                    Label("复制", systemImage: "doc.on.doc")
                }
            }
    }

    private func parseMarkdown(_ s: String) -> AttributedString {
        var attr = AttributedString(s)
        // 简单代码块标记
        if s.contains("```") {
            let parts = s.components(separatedBy: "```")
            var newAttr = AttributedString()
            for (i, part) in parts.enumerated() {
                if i.isMultiple(of: 2) {
                    newAttr += AttributedString(part)
                } else {
                    var code = AttributedString(part)
                    code.font = .system(.body, design: .monospaced)
                    code.foregroundColor = .primary
                    newAttr += code
                }
            }
            return newAttr
        }
        return attr
    }
}


// MARK: - 附件选择器

struct AttachmentPickerSheet: View {
    let onPick: (String, String) -> Void
    @Environment(\(dismiss)) private var dismiss
    @State private var textContent = ""
    @State private var fileName = "note.txt"
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("新建文本文件")) {
                    TextField("文件名", text: $fileName)
                    TextField("内容", text: $textContent, axis: .vertical)
                        .lineLimit(5...10)
                }
                
                Section(header: Text("或从本地文件选择")) {
                    Button(action: { pickFromFile() }) {
                        Label("从文件选择...", systemImage: "folder")
                    }
                }
            }
            .navigationTitle("附加文件")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("附加") {
                        let name = fileName.isEmpty ? "note.txt" : fileName
                        onPick(name, textContent.isEmpty ? "empty" : textContent)
                        dismiss()
                    }
                    .disabled(textContent.isEmpty && fileName == "note.txt")
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }
    
    private func pickFromFile() {
        // 简化版：实际应使用 PHPickerViewController
        // 这里暂用示例内容
        onPick("from_files.txt", "File selected from picker")
        dismiss()
    }
}
