// SettingsView.swift
// Author: 海鸥
// Purpose: 设置页面 - 一键配置向导

import SwiftUI

struct SettingsView: View {
    @StateObject private var settings = AppSettings.shared
    @State private var showLocalSetup = false

    @StateObject private var scanner = NetworkScanner()
    @State private var showTestResult: String? = nil
    @State private var isTesting = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationStack {
            Form {
                // 快速开始
                Section(header: Text("快速开始")) {
                    Button(action: { showAlert = true; alertMessage = "1. 选择AI后端 (推荐OpenAI或Groq)\n\n2. 输入API Key\n\n3. 点击测试连接\n\n4. 完成后即可使用" }) {
                        Label("配置指南", systemImage: "questionmark.circle")
                    }
                }
                
                // 演示模式
                Section(header: Text("离线模式")) {
                    Toggle("演示模式", isOn: $settings.demoMode)
                        .tint(.blue)
                    
                    if settings.demoMode {
                        Label("演示模式下无需网络连接", systemImage: "info.circle")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Button {
                        showLocalSetup = true
                    } label: {
                        Label("本地模型设置", systemImage: "cpu")
                            .font(.body)
                            .foregroundColor(.blue)
                    }
                    

                    

                }
                
                // 后端选择
                Section(header: Text("AI 后端")) {
                    Picker("后端", selection: $settings.backend) {
                        ForEach(AppSettings.backends, id: \.name) { backend in
                            Text(backend.displayName).tag(backend.name)
                        }
                    }
                    .onChange(of: settings.backend) { newBackend in
                        // 切换后端时自动更新默认模型和URL
                        if let backend = AppSettings.backends.first(where: { $0.name == newBackend }) {
                            settings.model = backend.defaultModel
                        }
                    }
                    
                    if settings.backend == "custom" {
                        TextField("自定义 API URL", text: $settings.customBaseURL)
                            .keyboardType(.URL)
                            .textInputAutocapitalization(.never)
                    } else if settings.serverIP.isEmpty {
                        // 云端服务 - 不需要IP
                        LabeledContent("服务器", value: "云端")
                    } else {
                        // 本地服务 - 需要IP
                        TextField("IP 地址", text: $settings.serverIP)
                            .keyboardType(.numbersAndPunctuation)
                        TextField("端口", value: $settings.port, formatter: NumberFormatter())
                            .keyboardType(.numbersAndPunctuation)
                    }
                }
                
                // 本地服务器扫描
                if settings.serverIP.isEmpty {
                    Section(header: Text("扫描本地服务器")) {
                        Button(action: { Task { await scanner.scan() } }) {
                            HStack {
                                Image(systemName: "antenna.radiowaves.left.and.right")
                                Text(scanner.isScanning ? "扫描中..." : "扫描局域网")
                                Spacer()
                                if scanner.isScanning {
                                    ProgressView()
                                }
                            }
                        }
                        .disabled(scanner.isScanning)
                        
                        if !scanner.discoveredServers.isEmpty {
                            ForEach(scanner.discoveredServers) { server in
                                Button(action: {
                                    settings.serverIP = server.ip
                                    settings.port = server.port
                                    settings.backend = server.type == .ollama ? "ollama" : (server.type == .llamaCpp ? "llamacpp" : "lmstudio")
                                }) {
                                    HStack {
                                        Image(systemName: "server.rack")
                                            .foregroundColor(.green)
                                        Text("\(server.ip):\(server.port)")
                                        Spacer()
                                        Text(server.type.rawValue)
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                        } else if !scanner.isScanning && !scanner.scanStatus.isEmpty {
                            Text(scanner.scanStatus)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Text("提示: 确保 Mac/PC 和 iPad 在同一 WiFi")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                
                // 模型
                Section(header: Text("模型")) {
                    TextField("模型名称", text: $settings.model)
                        .keyboardType(.asciiCapable)
                        .textInputAutocapitalization(.never)
                    
                    Slider(value: $settings.temperature, in: 0...2) {
                        Text("温度")
                    } minimumValueLabel: {
                        Text("0")
                    } maximumValueLabel: {
                        Text("2")
                    }
                    Text(String(format: "%.2f", settings.temperature))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                // API Key
                Section(header: Text("API Key")) {
                    if needsAPIKey {
                        SecureField("输入 API Key", text: $settings.apiKey)
                            .keyboardType(.asciiCapable)
                            .textInputAutocapitalization(.never)
                        Button(action: { openKeyPage() }) {
                            Label("如何获取 Key?", systemImage: "info.circle")
                        }
                        .foregroundColor(.blue)
                    } else {
                        LabeledContent("需要 Key", value: "不需要")
                    }
                }
                
                // 测试连接
                Section(header: Text("连接测试")) {
                    Button(action: { testConnection() }) {
                        if isTesting {
                            HStack {
                                ProgressView()
                                Text("测试中...")
                            }
                        } else {
                            Label("测试连接", systemImage: "network")
                        }
                    }
                    .disabled(isTesting)
                    
                    if let result = showTestResult {
                        HStack {
                            Image(systemName: result.contains("成功") ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundColor(result.contains("成功") ? .green : .red)
                            Text(result)
                                .font(.caption)
                        }
                    }
                }
                
                // 高级设置
                Section(header: Text("高级")) {
                    Stepper(value: $settings.maxRounds, in: 1...20) {
                        LabeledContent("最大轮数", value: "\(settings.maxRounds)")
                    }
                    
                    Section(header: Text("系统提示词")) {
                        TextEditor(text: $settings.systemPrompt)
                            .frame(height: 120)
                            .font(.caption)
                    }
                }
                
                // 关于
                Section(header: Text("关于")) {
                    LabeledContent("版本", value: "1.0")
                    LabeledContent("作者", value: "海鸥")
                    LabeledContent("后端", value: settings.backend.uppercased())
                    LabeledContent("服务器", value: serverInfo)
                }
            }
            .navigationTitle("设置")
            .alert("配置指南", isPresented: $showAlert) {
                Button("知道了") {}
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private var needsAPIKey: Bool {
        AppSettings.backends.first(where: { $0.name == settings.backend })?.needsKey ?? true
    }
    
    private var serverInfo: String {
        if settings.serverIP.isEmpty {
            return AppSettings.backends.first(where: { $0.name == settings.backend })?.defaultURL ?? "云端"
        } else {
            return "http://\(settings.serverIP):\(settings.port)"
        }
    }
    
    private func testConnection() {
        isTesting = true
        showTestResult = nil
        
        Task {
            do {
                let runner = settings.makeRunner()
                let response = try await runner.chat(
                    messages: [ChatMessage(role: "user", content: "Hello, test connection")],
                    stream: false
                )
                
                if !response.isEmpty {
                    await MainActor.run {
                        showTestResult = "✅ 连接成功! 模型响应: \(String(response.prefix(50)))..."
                        isTesting = false
                    }
                } else {
                    await MainActor.run {
                        showTestResult = "⚠️ 连接成功但无响应"
                        isTesting = false
                    }
                }
            } catch {
                await MainActor.run {
                    showTestResult = "❌ 连接失败: \(error.localizedDescription)"
                    isTesting = false
                }
            }
        }
    }
    
    private func openKeyPage() {
        // 根据后端打开对应的Key获取页面
        let url: String?
        switch settings.backend {
        case "openai":
            url = "https://platform.openai.com/api-keys"
        case "groq":
            url = "https://console.groq.com/keys"
        case "mistral":
            url = "https://console.mistral.ai/api-keys"
        default:
            url = nil
        }
        
        if let urlStr = url, let url = URL(string: urlStr) {
            UIApplication.shared.open(url)
        }
        .sheet(isPresented: $showLocalSetup) {
            LocalSetupView()
                .environmentObject(settings)
        }

    }
}
