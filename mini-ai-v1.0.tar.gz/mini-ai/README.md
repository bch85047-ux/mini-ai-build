# MiniAI — iPad本地AI Agent

无审查、联网搜索、文件读写、24h保留的本地AI助手。

## 架构

```
┌─────────────────────────────────────────┐
│  UI (SwiftUI App 或 CLI)                │
├─────────────────────────────────────────┤
│  ChatEngine (工具循环/消息管理)          │
├─────────────────────────────────────────┤
│  ModelRunner                            │
│   ├─ OpenAIRunner (兼容Ollama等)       │
│   └─ MLXRunner (原生本地, 待接入)       │
├─────────────────────────────────────────┤
│  Tools                                  │
│   ├─ SearchTool (Brave/HTTP抓取)       │
│   ├─ FileTool (工作区+24h清理)          │
│   └─ ShellTool (只读白名单)             │
└─────────────────────────────────────────┘
```

## 快速开始（CLI - 最快验证）

### 前置条件

- macOS + Xcode 15+（编译用）
- Swift 5.9+
- 一台能跑大模型的设备（Mac或同网络机器）

### Step 1: 启动本地模型服务

**Option A: Ollama（最简单）**

```bash
brew install ollama
ollama serve
ollama pull qwen2.5:7b-instruct        # 8GB内存可用
# 或 ollama pull qwen2.5:14b-instruct  # 16GB内存
# 或 ollama pull deepseek-r1:14b        # 推理更强
# 或 ollama pull llama3.1:8b
```

**Option B: llama.cpp server**

```bash
brew install llama.cpp
# 下载模型 (abliterated无审查)
huggingface-cli download huihui-ai/Qwen2.5-7B-Instruct-abliterated-4bit \
  --local-dir ./models/qwen2.5-7b-abliterated

llama-server -m ./models/qwen2.5-7b-abliterated/qwen2.5-7b-instruct-abliterated-fp16.gguf \
  --port 8080 \
  --ctx-size 8192
```

**Option C: LM Studio（GUI）**

- 下载 [LM Studio](https://lmstudio.ai)
- 导入 abliterated 模型（HuggingFace搜 `abliterated 4bit`）
- Start Server（端口1234，OpenAI兼容API）

### Step 2: 编译运行CLI

```bash
cd mini-ai
swift build
swift run mini-ai-cli --backend ollama --model qwen2.5:7b-instruct
```

### Step 3: 交互式使用

```
You> 今天北京天气怎么样？
  🔧 Tool: web_search [call_abc123]
  ✓ Result (512 chars)
AI>  北京今天晴朗，气温25-28度。

You> 帮我写一个python脚本算斐波那契数列前100项
AI>  ```python
     import sys
     sys.setrecursionlimit(1000)
     ...
     ```

You> 把这段代码保存到文件
  🔧 Tool: file_ops [call_def456]
  ✓ Result (45 chars)
AI>  已保存到 workspace/fib.py
```

### 命令速查

- `/help` 帮助
- `/tools` 列出工具
- `/history` 显示消息数
- `/reset` 清空历史
- `/exit` 退出

## 编译为iPad App

### Step 1: Xcode新建项目

1. Open Xcode → New Project → iOS App
2. Product Name: `MiniAIApp`
3. Interface: SwiftUI
4. Creation Location: 你想放的位置

### Step 2: 添加MiniAI依赖

Project → Package Dependencies → Add Package → 输入本地路径
`file:///path/to/mini-ai`
或把 `mini-ai` 目录拖到Xcode项目根目录。

Target Dependencies → `MiniAICore`。

### Step 3: 配置Info.plist

```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsLocalNetworking</key>
    <true/>
</dict>
<key>UIFileSharingEnabled</key>
<true/>
<key>LSSupportsOpeningDocumentsInPlace</key>
<true/>
<key>UIFileProtectionComplete</key>
<true/>
```

### Step 4: 建ChatView.swift

```swift
import SwiftUI
import MiniAICore

@Observable
class ChatModel {
    var messages: [(role: String, text: String)] = []
    var input = ""
    var isLoading = false

    private var engine: ChatEngine?

    init() {
        // 修改成你的后端地址
        let runner = OpenAIRunner(config: .init(
            baseURL: URL(string: "http://192.168.1.100:11434/api")!,  // 你的Mac/Ollama地址
            apiKey: "ollama",
            model: "qwen2.5:7b-instruct"
        ))
        let engine = ChatEngine(runner: runner, maxToolRounds: 8)
        engine.loadStandardTools()
        self.engine = engine
    }

    @MainActor
    func send() async {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isLoading, let engine else { return }
        input = ""
        messages.append(("user", text))
        isLoading = true
        defer { isLoading = false }

        do {
            let reply = try await engine.chat(userMessage: text)
            messages.append(("assistant", reply))
        } catch {
            messages.append(("assistant", "Error: \(error.localizedDescription)"))
        }
    }
}

struct ChatView: View {
    @State private var model = ChatModel()

    var body: some View {
        NavigationStack {
            VStack {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        ForEach(Array(model.messages.enumerated()), id: \.offset) { _, msg in
                            HStack {
                                if msg.role == "user" { Spacer() }
                                Text(msg.text)
                                    .padding(12)
                                    .background(msg.role == "user" ? Color.blue : Color(.systemGray5))
                                    .foregroundStyle(msg.role == "user" ? .white : .primary)
                                    .cornerRadius(12)
                                if msg.role != "user" { Spacer() }
                            }
                        }
                        if model.isLoading {
                            HStack {
                                Text("thinking...")
                                    .padding(12)
                                    .background(Color(.systemGray5))
                                    .cornerRadius(12)
                                Spacer()
                            }
                        }
                    }
                    .padding()
                }
                HStack {
                    TextField("消息...", text: $model.input)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit { Task { await model.send() } }
                    Button("发送") { Task { await model.send() } }
                        .buttonStyle(.borderedProminent)
                        .disabled(model.isLoading)
                }
                .padding()
            }
            .navigationTitle("MiniAI")
        }
    }
}
```

### Step 5: 替换App入口

```swift
@main
struct MiniAIApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView()
        }
    }
}
```

### Step 6: 设置运行目标

- Signing & Capabilities → Team
- Run Destination → 你的iPad（USB连接）
- Run (⌘R)

### Step 7: iPad网络访问

确保iPad和跑Ollama的Mac在同一WiFi。iPad上把 `192.168.1.100` 换成Mac的实际IP。

## 模型下载（无审查版）

**推荐（本地abliterated）：**

| 模型 | 大小 | 场景 |
|------|------|------|
| `huihui-ai/Qwen2.5-7B-Instruct-abliterated` | 4.5GB | 中文最强，8GB iPad |
| `huihui-ai/Qwen2.5-14B-Instruct-abliterated` | 8.5GB | 更聪明，16GB iPad |
| `huihui-ai/Llama-3.1-8B-Instruct-abliterated` | 5.0GB | 英文强，代码好 |

**下载命令：**

```bash
pip install huggingface-hub
huggingface-cli download huihui-ai/Qwen2.5-7B-Instruct-abliterated \
  --local-dir ./models/qwen2.5-7b-abliterated
```

## 部署拓扑（推荐）

```
    iPad Air (Chat UI)
        │
        │ WiFi (HTTP)
        ▼
    Mac mini (Ollama + 7B/14B模型)
```

iPad不跑模型（RAM不够），只跑UI+工具循环。Mac跑Ollama做推理。
这样iPad端CPU不烫，模型能跑7B/14B。

**纯本地（iPad单跑）：**

```
    iPad Air (UI + Ollama + Model)
```

需要 [Ollama for iOS](https://github.com/ollama/ollama) 或类似本地推理app。7B-4bit可用，但发热严重。

## 常见问题

**Q: iPad能直接跑Ollama吗？**
A: 官方不支持iOS。用 [PocketPal AI](https://apps.apple.com/us/app/pocketpal-ai) 做纯模型层，或用Mac远程。

**Q: 24h清理生效了吗？**
A: 每次启动app或FileTool时都会清理。检查 `Documents/MiniAIWorkspace/temp/` 目录。

**Q: Brave API key怎么拿？**
A: 去 [brave.com/search/api](https://brave.com/search/api/) 免费申请，日2000次。

**Q: 如何无审查？**
A: 用 `abliterated` 后缀模型（社区已剥离审查）。Ollama的模型通常带少量审查，可接受。

## 测试

```bash
swift test
```

跑通 `MiniAITests` 里的消息编解码、工具定义序列化。
