// Tool.swift
// Author: 海鸥
// Purpose: 工具协议 + JSON Schema 定义

import Foundation

/// JSON Schema类型描述
public enum JSONType: String {
    case string = "string"
    case integer = "integer"
    case number = "number"
    case boolean = "boolean"
    case array = "array"
    case object = "object"
    case anyOf = "anyOf"
}

public struct JSONProperty: Encodable {
    public let type: String
    public let description: String
    public let `enum`: [String]?
    public let items: JSONProperty?

    public init(type: JSONType, description: String, `enum`: [String]? = nil, items: JSONProperty? = nil) {
        self.type = type.rawValue
        self.description = description
        self.`enum` = `enum`
        self.items = items
    }
}

/// 单个工具的参数定义
public struct ToolParameter {
    public let type: JSONType
    public let description: String
    public let required: Bool
    public let `enum`: [String]?
    public let items: ToolParameter?

    public init(
        type: JSONType = .string,
        description: String,
        required: Bool = true,
        `enum`: [String]? = nil,
        items: ToolParameter? = nil
    ) {
        self.type = type
        self.description = description
        self.required = required
        self.`enum` = `enum`
        self.items = items
    }
}

/// OpenAI tools 数组条目
public struct ToolDefinition: Encodable {
    public let type: String
    public let function: FunctionDef

    public struct FunctionDef: Encodable {
        public let name: String
        public let description: String
        public let parameters: ParametersSchema
    }

    public struct ParametersSchema: Encodable {
        public let type: String
        public let properties: [String: JSONProperty]
        public let required: [String]
    }

    public init(name: String, description: String, parameters: [String: ToolParameter]) {
        self.type = "function"
        let props = parameters.mapValues { p in
            let itemsProp: JSONProperty? = p.items.map {
                JSONProperty(type: $0.type, description: $0.description, `enum`: $0.`enum`)
            }
            return JSONProperty(type: p.type, description: p.description, `enum`: p.`enum`, items: itemsProp)
        }
        let requiredKeys = parameters.compactMap { key, p in p.required ? key : nil }
        self.function = .init(
            name: name,
            description: description,
            parameters: .init(
                type: "object",
                properties: props,
                required: requiredKeys
            )
        )
    }
}

/// 可执行工具协议
public protocol Tool: AnyObject {
    var name: String { get }
    var description: String { get }
    var parameters: [String: ToolParameter] { get }
    func execute(_ args: [String: Any]) async throws -> String
}

public extension Tool {
    var definition: ToolDefinition {
        ToolDefinition(name: name, description: description, parameters: parameters)
    }
}

/// 工具结果封装
public struct ToolResult {
    public let callID: String
    public let success: Bool
    public let output: String

    public init(callID: String, success: Bool, output: String) {
        self.callID = callID
        self.success = success
        self.output = output
    }
}
