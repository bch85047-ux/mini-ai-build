// Message.swift
// Author: 海鸥
// Purpose: OpenAI Chat Completions 兼容的消息结构

import Foundation

public enum Role: String, Codable {
    case system
    case user
    case assistant
    case tool
}

/// 单次模型输出
public struct ModelOutput: Decodable {
    public let role: Role
    public let content: String?
    public let toolCalls: [ToolCall]?
}

public enum ModelOutputResponse: Decodable {
    case single(ModelOutput)
    case stream([String])  // chunked JSON fragments for streaming

    public var role: Role? {
        switch self {
        case .single(let o): return o.role
        case .stream: return nil
        }
    }
    public var content: String? {
        switch self {
        case .single(let o): return o.content
        case .stream: return nil
        }
    }
    public var toolCalls: [ToolCall]? {
        switch self {
        case .single(let o): return o.toolCalls
        case .stream: return nil
        }
    }
}

/// 模型请求工具调用的结构化输出
public struct ToolCall: Codable, Identifiable, Equatable {
    public let id: String
    public let type: String  // always "function"
    public let function: FunctionCall

    public struct FunctionCall: Codable, Equatable {
        public let name: String
        public let arguments: String  // JSON encoded
    }

    public init(id: String, type: String = "function", name: String, arguments: String) {
        self.id = id
        self.type = type
        self.function = .init(name: name, arguments: arguments)
    }
}

/// 对话消息，支持tool_call结果回传
public struct Message: Codable, Identifiable, Equatable {
    public let id: UUID
    public let role: Role
    public var content: String?
    public var toolCalls: [ToolCall]?
    public var toolCallID: String?

    public init(
        id: UUID = UUID(),
        role: Role,
        content: String? = nil,
        toolCalls: [ToolCall]? = nil,
        toolCallID: String? = nil
    ) {
        self.id = id
        self.role = role
        self.content = content
        self.toolCalls = toolCalls
        self.toolCallID = toolCallID
    }

    public static func system(_ text: String) -> Message {
        Message(role: .system, content: text)
    }
    public static func user(_ text: String) -> Message {
        Message(role: .user, content: text)
    }
    public static func assistant(_ text: String) -> Message {
        Message(role: .assistant, content: text)
    }
    public static func tool(_ text: String, forID: String) -> Message {
        Message(role: .tool, content: text, toolCallID: forID)
    }
    public static func assistantToolCall(_ calls: [ToolCall]) -> Message {
        Message(role: .assistant, toolCalls: calls)
    }
}

/// 模型请求体的完整结构
public struct ChatRequest: Encodable {
    public let model: String
    public let messages: [Message]
    public let tools: [ToolDefinition]?
    public let temperature: Double?
    public let maxTokens: Int?
    public let topP: Double?
    public let stream: Bool

    public init(
        model: String,
        messages: [Message],
        tools: [ToolDefinition]? = nil,
        temperature: Double? = nil,
        maxTokens: Int? = nil,
        topP: Double? = nil,
        stream: Bool = false
    ) {
        self.model = model
        self.messages = messages
        self.tools = tools
        self.temperature = temperature
        self.maxTokens = maxTokens
        self.topP = topP
        self.stream = stream
    }
}

public enum MiniAIError: Error, LocalizedError {
    case modelError(String)
    case toolError(String)
    case encodingError(String)
    case networkError(String)
    case unexpectedResponse(String)

    public var errorDescription: String? {
        switch self {
        case .modelError(let m): return "Model error: \(m)"
        case .toolError(let m): return "Tool error: \(m)"
        case .encodingError(let m): return "Encoding error: \(m)"
        case .networkError(let m): return "Network error: \(m)"
        case .unexpectedResponse(let m): return "Unexpected response: \(m)"
        }
    }
}
