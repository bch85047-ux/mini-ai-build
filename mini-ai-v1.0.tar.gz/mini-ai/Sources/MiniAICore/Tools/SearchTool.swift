// SearchTool.swift
// Author: 海鸥
// Purpose: 无审查Web搜索 - 多引擎回退

import Foundation

/// Web搜索工具，多引擎回退
/// - DuckDuckGo Instant Answer (无需key，结果少)
/// - Brave Search (需要API key，最好)
/// - Wikipedia (无需key，稳定)
/// - Bing HTML scraping (无需key，可能限流)
public final class SearchTool: Tool {
    public let name = "web_search"
    public let description = "Search the web for current information. Use for facts, news, prices, weather, recent events."
    public let parameters: [String: ToolParameter]

    private let braveAPIKey: String?
    private let session: URLSession

    public init(braveAPIKey: String? = nil) {
        self.parameters = [
            "query": ToolParameter(
                type: .string,
                description: "The search query in natural language. Be specific."
            ),
            "max_results": ToolParameter(
                type: .integer,
                description: "Maximum number of results to return (default 5).",
                required: false
            )
        ]
        self.braveAPIKey = braveAPIKey
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 15
        cfg.requestHeaders = ["User-Agent": "MiniAI/1.0 (local agent)"]
        self.session = URLSession(configuration: cfg)
    }

    public func execute(_ args: [String: Any]) async throws -> String {
        guard let query = args["query"] as? String, !query.isEmpty else {
            return "Error: 'query' is required"
        }
        let maxResults = (args["max_results"] as? Int) ?? 5

        // 优先Brave，回退Wikipedia，回退Bing scrape
        if let key = braveAPIKey, !key.isEmpty {
            if let result = try? await searchBrave(query: query, key: key, maxResults: maxResults), !result.isEmpty {
                return result
            }
        }
        if let wiki = try? await searchWikipedia(query: query, maxResults: maxResults), !wiki.isEmpty {
            return "Source: Wikipedia\n" + wiki
        }
        if let bing = try? await searchBing(query: query, maxResults: maxResults), !bing.isEmpty {
            return "Source: Bing (HTML scrape)\n" + bing
        }
        return "No results found for: \(query)"
    }

    // MARK: - Brave Search API (最佳质量，需key)
    private func searchBrave(query: String, key: String, maxResults: Int) async throws -> String {
        let enc = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let url = URL(string: "https://api.search.brave.com/res/v1/web/search?q=\(enc)&count=\(maxResults)")!
        var req = URLRequest(url: url)
        req.setValue("Accept", forHTTPHeaderField: "Accept")
        req.setValue("Accept: application/json", forHTTPHeaderField: "Accept")
        req.setValue("X-Subscription-Token: \(key)", forHTTPHeaderField: "X-Subscription-Token")
        req.setValue("User-Agent: MiniAI/1.0", forHTTPHeaderField: "User-Agent")

        let (data, _) = try await session.data(for: req)
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let web = json["web"] as? [String: Any],
              let results = web["results"] as? [[String: Any]] else {
            return ""
        }
        return results.prefix(maxResults).compactMap { r in
            guard let title = r["title"] as? String,
                  let url = r["url"] as? String else { return nil }
            let desc = r["description"] as? String ?? ""
            return "- \(title)\n  \(url)\n  \(desc)"
        }.joined(separator: "\n\n")
    }

    // MARK: - Wikipedia (无需key，稳定)
    private func searchWikipedia(query: String, maxResults: Int) async throws -> String {
        let enc = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let url = URL(string: "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srsearch=\(enc)&srlimit=\(maxResults)")!

        let (data, _) = try await session.data(from: url)
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let queryObj = json["query"] as? [String: Any],
              let results = queryObj["search"] as? [[String: Any]] else {
            return ""
        }
        return results.compactMap { r in
            guard let title = r["title"] as? String else { return nil }
            let snippet = stripHTML(r["snippet"] as? String ?? "")
            let url = "https://en.wikipedia.org/wiki/\(title.replacingOccurrences(of: " ", with: "_"))"
            return "- \(title)\n  \(url)\n  \(snippet)"
        }.joined(separator: "\n\n")
    }

    // MARK: - Bing HTML scraping (无需key，可能限流)
    private func searchBing(query: String, maxResults: Int) async throws -> String {
        let enc = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let url = URL(string: "https://www.bing.com/search?q=\(enc)&count=\(maxResults)")!
        var req = URLRequest(url: url)
        req.setValue("Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
                      forHTTPHeaderField: "User-Agent")

        let (data, response) = try await session.data(for: req)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            return ""
        }
        let html = String(data: data, encoding: .utf8) ?? ""
        return parseBingHTML(html, maxResults: maxResults)
    }

    private func parseBingHTML(_ html: String, maxResults: Int) -> String {
        var results: [String] = []
        // 匹配 li.b_algo 块
        let algoPattern = #"li class="b_algo".*?<h2.*?<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>.*?</li>"#
        let attrPattern = #"([a-zA-Z0-9_-]+)="([^"]*)""#
        if let regex = try? NSRegularExpression(pattern: algoPattern, options: [.dotMatchesLineSeparators]) {
            let range = NSRange(html.startIndex..., in: html)
            let matches = regex.matches(in: html, options: [], range: range)
            for match in matches.prefix(maxResults) {
                guard match.numberOfRanges >= 3 else { continue }
                let urlRange = match.range(at: 1)
                let titleRange = match.range(at: 2)
                guard let urlStr = String(range: urlRange, in: html) else { continue }
                let titleRaw = String(range: titleRange, in: html)
                let title = stripHTML(titleRaw)
                // 抓描述
                let snippetPattern = #"<p[^>]*>(.*?)</p>"#
                var snippet = ""
                if let snipRegex = try? NSRegularExpression(pattern: snippetPattern, options: [.dotMatchesLineSeparators]) {
                    let subRange = NSRange(html.index(html.index(match.range(at: 0).lowerBound, offsetBy: 200),
                                                      ..<html.endIndex,
                                                       by: .forward)?.description ?? 0..., in: html)
                    if let m = snipRegex.firstMatch(in: html, options: [], range: subRange),
                       m.numberOfRanges >= 2 {
                        snippet = stripHTML(String(range: m.range(at: 1), in: html))
                    }
                }
                _ = attrPattern
                results.append("- \(title)\n  \(urlStr)\n  \(snippet)")
            }
        }
        return results.joined(separator: "\n\n")
    }

    private func stripHTML(_ s: String) -> String {
        guard let stripped = try? String(
            data: s.data(using: .utf8)!,
            encoding: .utf8
        ) else { return s }
        let pattern = "<[^>]+>"
        return stripped.replacingOccurrences(of: pattern, with: "", options: .regularExpression)
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
