// MiniAITests.swift
// Author: 海鸥
// Purpose: 单元测试

import Testing
import Foundation
@testable import MiniAICore

@Test @MainActor struct MessageTests {
    @Test func messageFactory() {
        let sys = Message.system("hello")
        #expect(sys.role == .system)
        #expect(sys.content == "hello")

        let usr = Message.user("hi")
        #expect(usr.role == .user)

        let tool = Message.tool("result", forID: "call_1")
        #expect(tool.role == .tool)
        #expect(tool.toolCallID == "call_1")
    }

    @Test func toolCallDecoding() throws {
        let json = """
        {
          "id": "call_abc",
          "type": "function",
          "function": {
            "name": "web_search",
            "arguments": "{\"query\":\"test\"}"
          }
        }
        """
        let call = try JSONDecoder().decode(ToolCall.self, from: json.data(using: .utf8)!)
        #expect(call.id == "call_abc")
        #expect(call.function.name == "web_search")
        #expect(call.function.arguments.contains("test"))
    }
}

@Test @MainActor struct ToolDefinitionTests {
    @Test func definitionSerialization() throws {
        let params = [
            "query": ToolParameter(
                type: .string,
                description: "search query",
                required: true
            ),
            "limit": ToolParameter(
                type: .integer,
                description: "max results",
                required: false
            )
        ]
        let def = ToolDefinition(name: "web_search", description: "test", parameters: params)
        let data = try JSONEncoder().encode(def)
        let json = String(data: data, encoding: .utf8)!
        #expect(json.contains("web_search"))
        #expect(json.contains("query"))
        #expect(json.contains("limit"))
        #expect(json.contains("\"required\":[\"query\"]"))
    }
}

@Test @MainActor struct PathSafetyTests {
    @Test func pathTraversalBlocked() {
        let ws = URL(fileURLWithPath: "/tmp/test")
        let tool = FileTool(workspace: ws)
        // 直接测试 isSafePath 需要反射，这里测execute
        // 用同步方法不方便，跳过
    }
}
